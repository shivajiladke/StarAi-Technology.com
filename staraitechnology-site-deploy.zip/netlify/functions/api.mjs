/* ===========================================================
   Star Ai Exam Suite — api.mjs
   Netlify Function entry point. All logic lives in lib/api-core.mjs;
   this only wires it to Netlify Blobs for storage.
   =========================================================== */

import { getStore } from '@netlify/blobs';
import { handleApi } from './lib/api-core.mjs';

/* The store name is the address of your data on Netlify Blobs. It was
   renamed with the rest of the rebrand, so a deployment that already held
   exams under the old name would come up empty. If that applies to you,
   set EXAM_STORE_NAME=starai-exam and the old data is reachable again. */
const STORE_NAME = process.env.EXAM_STORE_NAME || 'zelite-exam';

const store = () => getStore(STORE_NAME);

const kv = {
  async get(key) {
    return (await store().get(key, { type: 'json' })) ?? null;
  },
  async put(key, value) {
    await store().setJSON(key, value);
  },
  async del(key) {
    await store().delete(key);
  },
  async listKeys(prefix) {
    const { blobs } = await store().list({ prefix });
    return blobs.map((b) => b.key);
  },
};

export default async (req) => handleApi(req, kv);

export const config = { path: '/api/*' };
