/* ===========================================================
   Star Ai Technology — main.js  (Premium Redesign)
   =========================================================== */

/* ── CONFIG ── */
const CONFIG = {
  whatsapp: "910000000000",
  linkedin: "https://www.linkedin.com/company/zelitetechnology",
  email:    "info@staraitechnology.com"
};

/* ── Wire WhatsApp & LinkedIn links ── */
const waURL = "https://wa.me/" + CONFIG.whatsapp +
  "?text=" + encodeURIComponent("Hi Star Ai Technology, I'd like to know more about your services.");
["wa-float", "wa-link", "wa-link-footer"].forEach(id => {
  const e = document.getElementById(id);
  if (e) { e.href = waURL; e.target = "_blank"; }
});
["li-link", "li-link-footer"].forEach(id => {
  const e = document.getElementById(id);
  if (e) { e.href = CONFIG.linkedin; e.target = "_blank"; }
});

/* ── Year ── */
const yr = document.getElementById("year");
if (yr) yr.textContent = new Date().getFullYear();

/* ══════════════════ TYPING ANIMATION ══════════════════ */
const typingWords = ["Star Ai Technology", "AI-Powered Solutions", "Cloud Excellence", "Digital Innovation"];
const typingEl = document.getElementById("typingText");
let wordIdx = 0, charIdx = 0, isDeleting = false, typingPause = false;

function typeWriter() {
  if (!typingEl) return;
  const currentWord = typingWords[wordIdx];

  if (typingPause) {
    typingPause = false;
    setTimeout(typeWriter, 1600);
    return;
  }

  if (isDeleting) {
    typingEl.textContent = currentWord.substring(0, charIdx - 1);
    charIdx--;
    if (charIdx === 0) {
      isDeleting = false;
      wordIdx = (wordIdx + 1) % typingWords.length;
      setTimeout(typeWriter, 400);
      return;
    }
    setTimeout(typeWriter, 35);
  } else {
    typingEl.textContent = currentWord.substring(0, charIdx + 1);
    charIdx++;
    if (charIdx === currentWord.length) {
      isDeleting = true;
      typingPause = true;
      setTimeout(typeWriter, 100);
      return;
    }
    setTimeout(typeWriter, 70);
  }
}
typeWriter();

/* ══════════════════ HEADER ══════════════════ */
const header = document.getElementById("header");
let lastScroll = 0;
addEventListener("scroll", () => {
  header.classList.toggle("scrolled", scrollY > 40);
});

/* ── Mobile menu ── */
const burger = document.getElementById("burger");
const navlinks = document.getElementById("navlinks");
burger.addEventListener("click", () => navlinks.classList.toggle("show"));
navlinks.querySelectorAll("a").forEach(a =>
  a.addEventListener("click", () => navlinks.classList.remove("show"))
);

/* ── Active nav link on scroll ── */
const sections = document.querySelectorAll("section[id]");
function updateActiveNav() {
  const scrollPos = scrollY + 200;
  sections.forEach(sec => {
    const top = sec.offsetTop;
    const h = sec.offsetHeight;
    const id = sec.getAttribute("id");
    const link = document.querySelector(`.navlinks a[href="#${id}"]`);
    if (link) {
      if (scrollPos >= top && scrollPos < top + h) {
        link.classList.add("active");
      } else {
        link.classList.remove("active");
      }
    }
  });
}
addEventListener("scroll", updateActiveNav);

/* ══════════════════ SCROLL PROGRESS BAR ══════════════════ */
const scrollProgress = document.getElementById("scrollProgress");
addEventListener("scroll", () => {
  const maxScroll = document.documentElement.scrollHeight - innerHeight;
  const pct = Math.min(scrollY / maxScroll, 1);
  scrollProgress.style.width = (pct * 100) + "%";
});

/* ══════════════════ BACK TO TOP ══════════════════ */
const backToTop = document.getElementById("backToTop");
addEventListener("scroll", () => {
  backToTop.classList.toggle("visible", scrollY > 500);
});
backToTop.addEventListener("click", () => {
  scrollTo({ top: 0, behavior: "smooth" });
});

/* ══════════════════ HERO CHIPS ══════════════════ */
const highlights = ["AI Solutions", "Cloud Services", "Automation", "IT Infrastructure", "Microsoft 365", "Azure", "Copilot"];
const hh = document.getElementById("hero-highlights");
highlights.forEach(h => hh.insertAdjacentHTML("beforeend", `<span class="chip">${h}</span>`));

/* ══════════════════ STATS ══════════════════ */
const statsData = [
  { num: 200, suffix: "+", label: "Projects Delivered" },
  { num: 50, suffix: "+", label: "Enterprise Clients" },
  { num: 99.9, suffix: "%", label: "Uptime Guarantee" },
  { num: 24, suffix: "/7", label: "Expert Support" }
];
const statsGrid = document.getElementById("statsGrid");
statsData.forEach(s => {
  statsGrid.insertAdjacentHTML("beforeend",
    `<div class="stat-item reveal">
      <div class="stat-num" data-count="${s.num}" data-suffix="${s.suffix}">0${s.suffix}</div>
      <div class="stat-label">${s.label}</div>
    </div>`
  );
});

/* Counter animation */
function animateCounters() {
  document.querySelectorAll(".stat-num[data-count]").forEach(el => {
    const target = parseFloat(el.dataset.count);
    const suffix = el.dataset.suffix;
    const isDecimal = target % 1 !== 0;
    const duration = 2000;
    const start = performance.now();

    function update(now) {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = eased * target;
      el.textContent = (isDecimal ? current.toFixed(1) : Math.floor(current)) + suffix;
      if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  });
}
// Trigger on scroll
let countersFired = false;
const statsSection = document.querySelector(".stats-section");
const statsObserver = new IntersectionObserver(entries => {
  if (entries[0].isIntersecting && !countersFired) {
    countersFired = true;
    animateCounters();
  }
}, { threshold: 0.3 });
if (statsSection) statsObserver.observe(statsSection);

/* ══════════════════ SERVICES DATA ══════════════════ */
const services = [
  { i: "🧠", t: "AI Solutions",        items: ["AI Chatbots & Assistants", "Copilot Solutions", "AI Automation Workflows", "Business Intelligence & Analytics"] },
  { i: "☁️", t: "Cloud Services",      items: ["Azure Migration & Strategy", "Cloud Infrastructure", "Backup & Disaster Recovery", "Cloud Security & Compliance"] },
  { i: "🪟", t: "Microsoft Solutions", items: ["Microsoft 365 Suite", "Exchange Online", "SharePoint & OneDrive", "Teams Deployment & Governance", "Intune Device Management"] },
  { i: "🖧", t: "IT Infrastructure",   items: ["Active Directory & Entra ID", "Network Architecture", "Firewall & Security", "Server Administration"] },
  { i: "⚙️", t: "Automation",          items: ["Power Automate Flows", "Copilot Studio Bots", "Workflow Optimization", "Process Mining & Analytics"] },
  { i: "📊", t: "Azure Solutions",     items: ["Azure App Services", "Azure AD / Entra ID", "Azure Storage & CDN", "Cost Optimization & FinOps"] }
];
const sg = document.getElementById("services-grid");
services.forEach(s => {
  const lis = s.items.map(x => `<li>${x}</li>`).join("");
  sg.insertAdjacentHTML("beforeend",
    `<div class="card service-card reveal"><div class="ico">${s.i}</div><h3>${s.t}</h3><ul>${lis}</ul></div>`);
});

/* ══════════════════ TECH MARQUEE ══════════════════ */
const techStack = [
  { icon: "⚡", name: "Azure" },
  { icon: "🤖", name: "AI & ML" },
  { icon: "☁️", name: "AWS" },
  { icon: "🐍", name: "Python" },
  { icon: "🟦", name: "TypeScript" },
  { icon: "⚛️", name: "React" },
  { icon: "🟢", name: "Node.js" },
  { icon: "🔷", name: ".NET" },
  { icon: "🗄️", name: "SQL Server" },
  { icon: "🍃", name: "MongoDB" },
  { icon: "🐳", name: "Docker" },
  { icon: "☸️", name: "Kubernetes" },
  { icon: "🔄", name: "Power Automate" },
  { icon: "📊", name: "Power BI" },
  { icon: "🏢", name: "SharePoint" },
  { icon: "💬", name: "Teams" },
  { icon: "🛡️", name: "Intune" },
  { icon: "🔐", name: "Entra ID" },
];
const marqueeTrack = document.getElementById("marqueeTrack");
const techHTML = techStack.map(t =>
  `<div class="tech-badge"><span class="tech-icon">${t.icon}</span>${t.name}</div>`
).join("");
// Duplicate for seamless loop
marqueeTrack.innerHTML = `<div class="marquee-inner">${techHTML}</div><div class="marquee-inner">${techHTML}</div>`;

/* ══════════════════ WHY CHOOSE US ══════════════════ */
const why = [
  { i: "👨‍💻", t: "Experienced IT Professionals", d: "Certified experts with deep domain knowledge" },
  { i: "🤖", t: "AI-Driven Solutions", d: "Cutting-edge AI for real business impact" },
  { i: "☁️", t: "Cloud Expertise", d: "Multi-cloud architecture & migration" },
  { i: "🕒", t: "24×7 Support", d: "Always-on monitoring & rapid response" },
  { i: "💰", t: "Cost Effective Services", d: "Maximum ROI with transparent pricing" },
  { i: "🔒", t: "Security First", d: "Enterprise-grade security at every layer" }
];
const wg = document.getElementById("why-grid");
why.forEach(w => wg.insertAdjacentHTML("beforeend",
  `<div class="card why-card reveal"><span class="tick">${w.i}</span><div><h3>${w.t}</h3><p style="font-size:.85rem;color:var(--muted);margin-top:4px">${w.d}</p></div></div>`));

/* ══════════════════ TESTIMONIALS ══════════════════ */
const testimonials = [
  {
    text: "Star Ai Technology transformed our entire IT infrastructure. Their Azure migration was seamless and reduced our costs by 40%.",
    name: "Rahul Sharma",
    role: "CTO, TechVentures Pvt Ltd",
    initials: "RS"
  },
  {
    text: "The AI chatbot they built for us handles 70% of customer queries automatically. Incredible ROI within just 3 months.",
    name: "Priya Patel",
    role: "Head of Operations, RetailMax",
    initials: "PP"
  },
  {
    text: "Their Microsoft 365 deployment and training was flawless. Our team productivity increased by 35% in the first quarter.",
    name: "Amit Deshmukh",
    role: "Managing Director, BuildRight Corp",
    initials: "AD"
  }
];
const tg = document.getElementById("testimonialsGrid");
testimonials.forEach(t => {
  tg.insertAdjacentHTML("beforeend",
    `<div class="testimonial-card reveal">
      <div class="testimonial-stars">★ ★ ★ ★ ★</div>
      <p class="testimonial-text">${t.text}</p>
      <div class="testimonial-author">
        <div class="testimonial-avatar">${t.initials}</div>
        <div>
          <div class="testimonial-name">${t.name}</div>
          <div class="testimonial-role">${t.role}</div>
        </div>
      </div>
    </div>`
  );
});

/* ══════════════════ REVEAL ON SCROLL ══════════════════ */
const io = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add("in");
      io.unobserve(e.target);
    }
  });
}, { threshold: 0.1 });
document.querySelectorAll(".reveal").forEach(el => io.observe(el));

/* ══════════════════ SERVICE CARD GLOW ══════════════════ */
document.querySelectorAll(".service-card").forEach(c => {
  c.addEventListener("mousemove", e => {
    const r = c.getBoundingClientRect();
    c.style.setProperty("--mx", (e.clientX - r.left) + "px");
    c.style.setProperty("--my", (e.clientY - r.top) + "px");
  });
});

/* ══════════════════ CUSTOM CURSOR ══════════════════ */
const cursorDot = document.getElementById("cursorDot");
const cursorRing = document.getElementById("cursorRing");
let mouseX = 0, mouseY = 0, ringX = 0, ringY = 0;

if (cursorDot && cursorRing && window.matchMedia("(pointer: fine)").matches) {
  addEventListener("mousemove", e => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    cursorDot.style.left = mouseX + "px";
    cursorDot.style.top = mouseY + "px";
  });

  function animateRing() {
    ringX += (mouseX - ringX) * 0.12;
    ringY += (mouseY - ringY) * 0.12;
    cursorRing.style.left = ringX + "px";
    cursorRing.style.top = ringY + "px";
    requestAnimationFrame(animateRing);
  }
  animateRing();

  // Hover state for interactive elements
  const hoverTargets = document.querySelectorAll("a, button, .card, .chip, .tech-badge, .btn, input, textarea");
  hoverTargets.forEach(el => {
    el.addEventListener("mouseenter", () => {
      cursorDot.classList.add("hover");
      cursorRing.classList.add("hover");
    });
    el.addEventListener("mouseleave", () => {
      cursorDot.classList.remove("hover");
      cursorRing.classList.remove("hover");
    });
  });
} else {
  // Hide cursor elements on touch devices
  if (cursorDot) cursorDot.style.display = "none";
  if (cursorRing) cursorRing.style.display = "none";
}

/* ══════════════════ CONTACT FORM ══════════════════ */
document.getElementById("contactForm").addEventListener("submit", e => {
  e.preventDefault();
  e.target.style.display = "none";
  document.getElementById("success").classList.add("show");
});

/* ══════════════════ PARTICLE BACKGROUND ══════════════════ */
const cv = document.getElementById("particles");
const cx = cv.getContext("2d");
let pts = [], W, H;

function resize() {
  W = cv.width = innerWidth;
  H = cv.height = innerHeight;
}
resize();
addEventListener("resize", resize);

// More particles with better distribution
const particleCount = Math.min(90, Math.floor(innerWidth / 15));
for (let i = 0; i < particleCount; i++) {
  pts.push({
    x: Math.random() * W,
    y: Math.random() * H,
    vx: (Math.random() - 0.5) * 0.35,
    vy: (Math.random() - 0.5) * 0.35,
    r: Math.random() * 1.8 + 0.5,
    hue: Math.random() > 0.5 ? 220 : 30 // blue or orange hue
  });
}

let mouseParticleX = -1000, mouseParticleY = -1000;
addEventListener("mousemove", e => {
  mouseParticleX = e.clientX;
  mouseParticleY = e.clientY;
});

function draw() {
  cx.clearRect(0, 0, W, H);
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    p.x += p.vx;
    p.y += p.vy;

    // Mouse repulsion
    const dmx = p.x - mouseParticleX;
    const dmy = p.y - mouseParticleY;
    const dm = Math.hypot(dmx, dmy);
    if (dm < 150) {
      const force = (1 - dm / 150) * 0.8;
      p.vx += (dmx / dm) * force;
      p.vy += (dmy / dm) * force;
    }

    // Dampen velocity
    p.vx *= 0.99;
    p.vy *= 0.99;

    // Bounce off edges
    if (p.x < 0 || p.x > W) p.vx *= -1;
    if (p.y < 0 || p.y > H) p.vy *= -1;

    // Draw particle
    const alpha = p.hue === 220 ? 0.6 : 0.5;
    const color = p.hue === 220 ? "100,160,255" : "255,160,80";
    cx.beginPath();
    cx.arc(p.x, p.y, p.r, 0, 7);
    cx.fillStyle = `rgba(${color},${alpha})`;
    cx.fill();

    // Draw connections
    for (let j = i + 1; j < pts.length; j++) {
      const q = pts[j];
      const dx = p.x - q.x;
      const dy = p.y - q.y;
      const d = Math.hypot(dx, dy);
      if (d < 130) {
        cx.beginPath();
        cx.moveTo(p.x, p.y);
        cx.lineTo(q.x, q.y);
        cx.strokeStyle = `rgba(80,140,255,${0.1 * (1 - d / 130)})`;
        cx.lineWidth = 0.5;
        cx.stroke();
      }
    }
  }
  requestAnimationFrame(draw);
}
draw();

/* ══════════════════ SMOOTH SCROLL FOR ALL ANCHORS ══════════════════ */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener("click", e => {
    const target = document.querySelector(a.getAttribute("href"));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  });
});
