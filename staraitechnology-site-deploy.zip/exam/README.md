# Star Ai Safe Exam Browser

A client-side MCQ examination suite with a locked-down candidate runner and a
separate admin panel. Lives under `/exam/` and reuses the main site's palette.

## Pages

| File | Role |
|------|------|
| `index.html` | Portal landing — routes to Candidate or Admin |
| `candidate.html` | Candidate login → briefing → **safe-mode exam** → result |
| `admin.html` | Admin panel — build papers, issue codes, review results |

## Admin accounts (master + workers)

There is one **master** admin who manages any number of **worker** admins:

- First run, sign in as **`master`** / **`1234`** (change the password under *Settings*).
- The master's **Admins** tab creates workers, each with their own username and
  password and a permission set: **Exams**, **Candidates**, **Results**, **AI**.
- The master can **enable/disable**, **reset a password**, **change permissions**,
  and **delete** any worker. Disabling or deleting signs the worker out immediately
  and blocks their next request — no waiting for the token to expire.
- Every permission is **enforced on the server**, not just hidden in the UI. A
  worker who lacks a permission cannot perform that action even by calling the API
  directly. A candidates-only worker sees just the access-code view for each exam.

Recovery: if the master password is lost, set `EXAM_ADMIN_PIN` on the server (see
DEPLOY-VM.md) — it overrides the master password until unset.

## How to use

1. **Admin** → open `admin.html`, sign in (first run: **`master`** / **`1234`**, change it under *Settings*).
2. Create an exam, add MCQ questions (mark the correct option with the green radio),
   set duration / pass % / negative marking / max violations, then **Publish**.
3. Issue codes in the exam editor:
   - **⚡ Generate code** — one click, creates a code instantly and shows it on a
     large hand-out card. Rename the candidate later by typing over the name cell.
   - **＋ Add** — type a name first, then add.
   - **⇪ Bulk add** — one name per line.
4. **Candidate** → open `candidate.html`, enter the code. The flow is:
   1. **Instructions** — question count, marks, duration, pass mark, safe-mode rules;
      tick the agreement and press **Enter Safe Mode & Start**.
   2. **Identity confirmation** — safe mode engages, then the candidate's **name
      (pulled from the admin's candidate record)** is shown with their initials,
      access code, exam title, question count and duration. It auto-advances after
      5 seconds, or they can press **Begin exam**. Their name stays pinned in the
      exam top bar throughout.
   3. **MCQs** — with a **countdown timer in the corner**, set from the exam's
      *Duration* field. The clock starts on the first question, not on the identity
      screen, so confirmation time isn't deducted.
5. Results appear live under the admin **Results** tab (with per-question review,
   violation log, and CSV export).

### ✨ Generate an exam with AI

In the exam editor, a **Generate from the title** panel sits under *Title*. Type a
real title (e.g. "AI Trainee Engineer"), set how many questions you want, and press
**Generate with AI**. It writes the description, then the questions in batches of 10,
showing progress as it goes. **Stop** halts after the current batch and keeps
everything generated so far.

Generated questions are **added** to the paper — nothing is replaced — and are
ordinary questions you can edit, delete, or re-mark afterwards. **Review them
before publishing**; the publish validator catches structural problems, not
factual ones.

**Setup.** The button only appears when the server has an Anthropic API key:

```bash
# Self-hosted — set alongside PORT / DATA_DIR
ANTHROPIC_API_KEY=sk-ant-...

# Netlify — Site settings → Environment variables
```

The key is read **server-side only** and never reaches the browser. Without it
(or without `npm install`), the panel is hidden and the rest of the suite works
exactly as before — AI authoring is an admin convenience, not a dependency for
sitting exams.

### Bulk import questions
In the exam editor → *Bulk import*, one per line:
```
Question text | option1 | option2 | option3 | option4 | correctNumber
```
`correctNumber` is the 1-based index of the correct option.

## "Safe browser" — what it does and doesn't do

The candidate runner enforces (via [`js/lockdown.js`](js/lockdown.js)):

- Forced **fullscreen**; leaving it is logged and shows a recovery banner
- **Tab-switch / window-blur** detection
- **Copy / cut / paste / right-click / print** blocking
- Blocked shortcuts: devtools (F12, Ctrl+Shift+I/J/C), Ctrl+C/V/X/A/S/P/F/U, Ctrl+T/N/W
- A **violation counter** — after *max violations* the exam **auto-submits** ("terminated")
- A non-pausing timer that auto-submits at zero

> ⚠️ **This is a deterrent, not a guarantee.** Web-page lockdown cannot stop a
> determined candidate with a second device, a screenshot, or a virtual machine.
> For high-stakes exams, pair this with a real kiosk browser and a server backend.

## Accessibility

Options are real `<button>`s with `role="radio"` inside a `role="radiogroup"`:
Tab reaches the group, **arrow keys** move between options (wrapping), **Home/End**
jump to first/last, and Enter/Space select. Focus is always visible. Arrowing onto
the current choice never clears it — only clicking the selected option toggles it off.
`prefers-reduced-motion` disables the last-minute timer pulse and other animation.

## Architecture

Exams, access codes, the answer key and scoring live **on the server**, in a
Netlify Function backed by Netlify Blobs:

```
netlify/functions/api.mjs           Netlify entry point (Blobs storage adapter)
netlify/functions/lib/api-core.mjs  all API logic, storage-agnostic
.claude/dev-server.mjs              local dev: same api-core, in-memory storage
```

The earlier build kept everything in `localStorage`, which is per-browser — a
candidate opening the site on their own device saw an empty database, so every
access code came back **"Invalid access code"**. That is why this exists.

### API

| Endpoint | Purpose | Requires |
|---|---|---|
| `POST /api/admin/login` | username + password → bearer token (8h) | — |
| `GET /api/admin/db` | exams + candidates + attempts + identity | any admin |
| `PUT /api/admin/exams` | save exams (never attempts) | `exams` perm |
| `PUT /api/admin/candidates` | save access codes | `candidates` perm |
| `DELETE /api/admin/attempt` | reset a candidate's attempt | `candidates` perm |
| `POST /api/admin/generate` | AI question/description generation | `ai` perm |
| `POST /api/admin/password` | change your own password | any admin |
| `GET/POST /api/admin/admins[...]` | list / create / update / reset / delete admins | master |
| `POST /api/candidate/login` | access code → token + **sanitised** exam | — |
| `POST /api/candidate/begin` | starts the server-side clock | candidate token |
| `POST /api/candidate/answer` `/flag` `/violation` `/submit` | token-scoped | candidate token |

Exam and candidate writes are **separate, permission-gated endpoints**, so an
admin who may only issue codes never even attempts an exam write. Neither ever
writes attempts, so an admin save can't clobber a candidate mid-sitting.

## Data & security model

- **The answer key never reaches the browser.** Candidates receive a sanitised
  exam (`id`, `text`, `options`, `marks` only) and scoring runs on the server, so
  the answers cannot be read out of devtools.
- **Candidates are token-scoped.** A candidate token grants access to that one
  attempt; admin endpoints reject it.
- Each admin's password is stored **salted + scrypt-hashed** and compared in
  constant time. Change the master's from `1234` before issuing real codes.
- **Every permission is enforced server-side**, keyed to the token's live admin
  record — a disable, delete, or permission change applies on the very next
  request. UI gating is only cosmetic; the server is the boundary.
- Question order and option order are fixed **server-side at first login**, so a
  reload cannot reshuffle the paper.
- The exam deadline is set and stored **server-side**, so the clock cannot be
  extended by editing the page.
- **Exams are validated before publishing** — empty question text, fewer than two
  options, a blank or missing correct answer, zero marks, zero duration, or a
  missing title all block publication and are listed for fixing.
- **Access codes are checked for collisions** when issued, so two candidates can
  never share a login.
- If an examiner resets an attempt while the candidate still has the exam open,
  that tab **stands down** instead of writing its copy back — the candidate sees a
  "Your exam was reset" notice. Without this, a stale tab silently undid the reset.
- To make it production-grade: move exams, the answer key and scoring **server-side**,
  authenticate candidates against the server, and record submissions server-side.

## Files

```
exam/
  index.html          portal landing
  candidate.html      candidate + exam runner
  admin.html          admin panel
  css/exam.css        shared styles (site palette)
  js/
    store.js          localStorage data layer + scoring
    lockdown.js       safe-exam lockdown engine
    candidate.js      candidate flow controller
    admin.js          admin panel controller
    ui.js             DOM helpers (toast, modal, escaping)
```
