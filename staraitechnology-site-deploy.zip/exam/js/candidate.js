/* ===========================================================
   Star Ai Exam Suite — candidate.js
   Candidate flow: code login → briefing → identity → safe-mode
   exam → result.

   All exam data comes from the server (/api/candidate/*). The
   answer key never reaches this file and scoring happens server-
   side, so a candidate can sit the exam from any device and can't
   read the answers out of devtools.
   =========================================================== */

import { $, el, esc, toast, confirmModal } from './ui.js';
import { createLockdown } from './lockdown.js';

const API = '/api';

/* runtime session state */
const S = {
  token: null,
  candidate: null,
  exam: null,        // sanitised — no answer key
  answers: {},
  flags: {},
  order: [],
  optOrder: {},
  violations: 0,
  current: 0,
  lock: null,
  timerId: null,
  identTimer: null,
  endsAt: 0,
  begun: false,
  finished: false,
  aborted: false,
};

const views = ['loginView', 'briefView', 'identityView', 'examView', 'resultView'];
function show(view) {
  views.forEach((v) => $(`#${v}`).classList.toggle('hidden', v !== view));
}

/* ═══════════════ TRANSPORT ═══════════════ */

async function api(path, body) {
  const res = await fetch(`${API}/${path}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body ?? {}),
  });

  let data = null;
  try { data = await res.json(); } catch { /* empty */ }

  if (!res.ok) {
    // 409 + error:'reset' means the examiner wiped this attempt
    if (res.status === 409 && data?.error === 'reset') { abortForReset(); throw new Error('reset'); }
    const err = new Error(data?.error || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

/* Serialize every attempt-mutating write into a single in-order chain.
   The server does read-modify-write on the whole attempt with no locking,
   so two answer saves in flight at once would clobber each other and lose
   answers (which showed up as "skipped" on a fully-answered paper). One
   request at a time means the server processes them sequentially. */
let writeChain = Promise.resolve();

function enqueueWrite(path, body, { silent = true } = {}) {
  const run = () => api(path, body);
  const p = writeChain.then(run, run);        // run regardless of prior outcome
  writeChain = p.catch(() => {});             // keep the chain alive past failures
  if (silent) {
    p.catch((err) => {
      if (err.message === 'reset') return;
      toast('Connection problem — your last action may not be saved', 'err');
    });
  }
  return p;
}

function abortForReset() {
  if (S.aborted) return;
  S.aborted = true;
  clearInterval(S.timerId);
  clearInterval(S.identTimer);
  S.lock && S.lock.stop();
  $('#fsBanner').classList.add('hidden');
  $('#resetBanner').classList.remove('hidden');
}

/* ═══════════════ LOGIN ═══════════════ */

$('#loginBtn').addEventListener('click', doLogin);
$('#codeInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') doLogin(); });

async function doLogin() {
  const btn = $('#loginBtn');
  const code = $('#codeInput').value.trim().toUpperCase();
  if (!code) { toast('Enter your access code', 'err'); return; }

  btn.disabled = true;
  btn.textContent = 'Checking…';
  try {
    const data = await api('candidate/login', { code });

    if (data.status === 'done') {
      S.exam = { title: data.exam.title, showResultToCandidate: data.exam.showResultToCandidate };
      S.candidate = data.candidate;
      showResult({ status: data.attempt.status, violations: data.attempt.violations }, data.result);
      return;
    }

    S.token = data.token;
    S.candidate = data.candidate;
    S.exam = data.exam;
    S.answers = data.attempt.answers ?? {};
    S.flags = data.attempt.flags ?? {};
    S.order = data.attempt.order ?? [];
    S.optOrder = data.attempt.optOrder ?? {};
    S.violations = data.attempt.violations ?? 0;
    S.endsAt = data.attempt.endsAt ? new Date(data.attempt.endsAt).getTime() : 0;

    showBriefing();
  } catch (err) {
    if (err.message !== 'reset') toast(err.message, 'err');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Continue';
  }
}

/* ═══════════════ BRIEFING ═══════════════ */

function totalMarks() {
  return S.exam.questions.reduce((s, q) => s + (Number(q.marks) || 0), 0);
}

function showBriefing() {
  const e = S.exam;
  $('#briefTitle').textContent = e.title;
  $('#briefDesc').textContent = e.description || '';
  $('#briefQs').textContent = e.questions.length;
  $('#briefMarks').textContent = totalMarks();
  $('#briefDur').textContent = e.durationMin;
  $('#briefPass').textContent = `${e.passPercent}%`;
  $('#briefMaxViol').textContent = e.maxViolations;
  $('#agreeChk').checked = false;
  $('#startBtn').disabled = true;
  show('briefView');
}

$('#agreeChk').addEventListener('change', (e) => { $('#startBtn').disabled = !e.target.checked; });
$('#briefBackBtn').addEventListener('click', () => location.reload());
$('#startBtn').addEventListener('click', startExam);

/* ═══════════════ START ═══════════════ */

async function startExam() {
  S.current = 0;

  S.lock = createLockdown({
    maxViolations: S.exam.maxViolations,
    onViolation: async (entry) => {
      if (entry.reason === 'Left fullscreen mode') $('#fsBanner').classList.remove('hidden');
      try {
        // the server owns the count and decides when to terminate; goes
        // through the same write queue so it can't race the answer saves
        const r = await enqueueWrite('candidate/violation', { token: S.token, reason: entry.reason }, { silent: false });
        S.violations = r.count;
        updateViolChip();
        toast(`⚠ ${entry.reason} (${r.count}/${S.exam.maxViolations})`, 'err');
        if (r.terminated) endExam('terminated', r.result);
      } catch (err) {
        if (err.message !== 'reset') toast(`⚠ ${entry.reason}`, 'err');
      }
    },
    onTerminate: () => { /* server-driven; see above */ },
  });

  await S.lock.start();
  showIdentity();
}

/* ═══════════════ IDENTITY ═══════════════ */

function initials(name) {
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '??';
  return (parts[0][0] + (parts[1]?.[0] ?? '')).toUpperCase();
}

function showIdentity() {
  const c = S.candidate;
  const e = S.exam;

  $('#identAvatar').textContent = initials(c.name);
  $('#identName').textContent = c.name;
  $('#identCode').textContent = c.code;
  $('#identExam').textContent = e.title;
  $('#identQs').textContent = e.questions.length;
  $('#identDur').textContent = `${e.durationMin} min`;
  $('#identWarn').textContent = S.endsAt
    ? 'Resuming your exam in progress — your original timer is still running.'
    : 'If this is not you, close the exam and tell your examiner immediately.';

  show('identityView');

  let left = 5;
  const label = $('#beginCount');
  label.textContent = `(${left})`;
  S.identTimer = setInterval(() => {
    left--;
    if (left <= 0) { beginQuestions(); return; }
    label.textContent = `(${left})`;
  }, 1000);
}

$('#beginBtn').addEventListener('click', beginQuestions);

async function beginQuestions() {
  if (S.begun || S.aborted) return;
  S.begun = true;
  clearInterval(S.identTimer);

  try {
    // server sets (or returns) the deadline — the clock can't be gamed here
    const { endsAt } = await api('candidate/begin', { token: S.token });
    S.endsAt = new Date(endsAt).getTime();
  } catch (err) {
    if (err.message === 'reset') return;
    toast(`Could not start: ${err.message}`, 'err');
    S.begun = false;
    return;
  }

  show('examView');
  $('#examName').textContent = S.exam.title;
  $('#candName').textContent = S.candidate.name;
  renderPalette();
  renderQuestion();
  updateViolChip();
  startTimer();
}

/* ═══════════════ FULLSCREEN BANNER ═══════════════ */

$('#resumeFsBtn').addEventListener('click', async () => {
  await S.lock.requestFullscreen();
  $('#fsBanner').classList.add('hidden');
});

document.addEventListener('fullscreenchange', () => {
  if (S.lock && S.lock.active && S.lock.isFullscreen()) $('#fsBanner').classList.add('hidden');
});

/* ═══════════════ QUESTIONS ═══════════════ */

function currentQ() {
  const qid = S.order[S.current];
  return S.exam.questions.find((q) => q.id === qid);
}

function renderQuestion() {
  const q = currentQ();
  const card = $('#qCard');
  card.innerHTML = '';

  const given = S.answers[q.id];
  const order = S.optOrder[q.id] ?? q.options.map((_, i) => i);

  const optNodes = order.map((realIdx, displayIdx) => {
    const selected = given === realIdx;
    const letter = String.fromCharCode(65 + displayIdx);
    const text = q.options[realIdx] || `Option ${displayIdx + 1}`;
    return el('button', {
      type: 'button',
      class: `opt ${selected ? 'selected' : ''}`,
      role: 'radio',
      'aria-checked': selected ? 'true' : 'false',
      'aria-label': `Option ${letter}: ${text}`,
      tabindex: selected || (given === undefined && displayIdx === 0) ? '0' : '-1',
      onclick: () => selectOption(q.id, realIdx),
      onkeydown: (e) => onOptionKey(e, q.id, order, displayIdx),
    }, [
      el('span', { class: 'mark', 'aria-hidden': 'true' }, letter),
      el('span', { class: 'grow' }, text),
    ]);
  });

  card.append(
    el('div', { class: 'spread row' }, [
      el('span', { class: 'q-num' }, `Question ${S.current + 1} of ${S.order.length}`),
      el('span', { class: 'muted', style: 'font-size:0.8rem;' }, `${q.marks} mark${q.marks === 1 ? '' : 's'}`),
    ]),
    el('div', { class: 'q-text', id: 'qTextLabel' }, q.text || '(no question text)'),
    el('div', { role: 'radiogroup', 'aria-labelledby': 'qTextLabel' }, optNodes),
  );

  $('#prevBtn').disabled = S.current === 0;
  $('#nextBtn').disabled = S.current === S.order.length - 1;
  $('#flagBtn').textContent = S.flags[q.id] ? '⚑ Flagged' : '⚑ Flag for review';
  updatePalette();
}

/* Arrow keys move within the group; Home/End jump to the ends. */
function onOptionKey(e, qid, order, displayIdx) {
  const keys = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 };
  let next = null;

  if (e.key in keys) next = (displayIdx + keys[e.key] + order.length) % order.length;
  else if (e.key === 'Home') next = 0;
  else if (e.key === 'End') next = order.length - 1;
  else return;

  e.preventDefault();
  // setOption, not selectOption: arrowing onto the current choice must not clear it
  setOption(qid, order[next]);
  document.querySelectorAll('.q-card .opt')[next]?.focus();
}

function setOption(qid, realIdx) {
  S.answers[qid] = realIdx;
  enqueueWrite('candidate/answer', { token: S.token, qid, index: realIdx });
  renderQuestion();
}

function selectOption(qid, realIdx) {
  let index;
  if (S.answers[qid] === realIdx) { delete S.answers[qid]; index = null; }  // toggle off
  else { S.answers[qid] = realIdx; index = realIdx; }
  enqueueWrite('candidate/answer', { token: S.token, qid, index });
  renderQuestion();
}

$('#prevBtn').addEventListener('click', () => { if (S.current > 0) { S.current--; renderQuestion(); } });
$('#nextBtn').addEventListener('click', () => { if (S.current < S.order.length - 1) { S.current++; renderQuestion(); } });
$('#flagBtn').addEventListener('click', () => {
  const q = currentQ();
  const value = !S.flags[q.id];
  if (value) S.flags[q.id] = true; else delete S.flags[q.id];
  enqueueWrite('candidate/flag', { token: S.token, qid: q.id, value });
  renderQuestion();
});

/* ═══════════════ PALETTE ═══════════════ */

/* Collapsed on phones (CSS decides); tapping a number jumps to the
   question, so close the panel afterwards or the answer stays hidden
   behind the grid. */
const paletteIsCollapsible = () => window.matchMedia('(max-width: 900px)').matches;

function setPaletteOpen(open) {
  $('#palettePanel').classList.toggle('open', open);
  $('#paletteToggle').setAttribute('aria-expanded', open ? 'true' : 'false');
}

$('#paletteToggle').addEventListener('click', () => {
  if (!paletteIsCollapsible()) return;      // plain heading on desktop
  setPaletteOpen(!$('#palettePanel').classList.contains('open'));
});

function renderPalette() {
  const host = $('#palette');
  host.innerHTML = '';
  S.order.forEach((qid, i) => {
    host.append(el('button', {
      class: 'pal-btn', 'data-i': i,
      onclick: () => {
        S.current = i;
        renderQuestion();
        if (paletteIsCollapsible()) {
          setPaletteOpen(false);
          $('#qCard').scrollIntoView({ block: 'start', behavior: 'smooth' });
        }
      },
    }, String(i + 1)));
  });
  updatePalette();
}

function updatePalette() {
  const btns = $('#palette').children;
  let answered = 0;
  S.order.forEach((qid, i) => {
    const b = btns[i];
    if (!b) return;
    const has = S.answers[qid] !== undefined;
    b.classList.toggle('answered', has);
    b.classList.toggle('flagged', !!S.flags[qid] && !has);
    b.classList.toggle('current', i === S.current);
    if (has) answered++;
  });
  $('#answeredCount').textContent = `${answered}/${S.order.length}`;
}

function updateViolChip() {
  const chip = $('#violChip');
  chip.classList.toggle('hidden', S.violations === 0);
  chip.textContent = `⚠ ${S.violations} flag${S.violations === 1 ? '' : 's'}`;
}

/* ═══════════════ TIMER ═══════════════ */

function startTimer() {
  tick();
  S.timerId = setInterval(tick, 1000);
}

function tick() {
  const remaining = Math.max(0, S.endsAt - Date.now());
  const total = S.exam.durationMin * 60 * 1000;
  const secs = Math.floor(remaining / 1000);
  const mm = String(Math.floor(secs / 60)).padStart(2, '0');
  const ss = String(secs % 60).padStart(2, '0');

  const warn = remaining < total * 0.25 && remaining >= 60000;
  const danger = remaining < 60000;

  const t = $('#timer');
  t.textContent = `${mm}:${ss}`;
  t.classList.toggle('warn', warn);
  t.classList.toggle('danger', danger);

  const box = $('#timerFloat');
  box.classList.toggle('warn', warn);
  box.classList.toggle('danger', danger);
  $('#timerBar').style.width = `${Math.max(0, Math.min(100, (remaining / total) * 100))}%`;

  if (remaining <= 0) {
    clearInterval(S.timerId);
    toast('Time is up — submitting', 'err');
    submitExam('submitted');
  }
}

/* ═══════════════ SUBMIT ═══════════════ */

$('#submitBtn').addEventListener('click', async () => {
  const answered = Object.keys(S.answers).length;
  const total = S.order.length;
  const unanswered = total - answered;
  const flagged = Object.values(S.flags).filter(Boolean).length;

  const parts = [];
  if (unanswered) parts.push(`${unanswered} unanswered`);
  if (flagged) parts.push(`${flagged} flagged for review`);

  const ok = await confirmModal({
    title: 'Submit your exam?',
    body: parts.length
      ? `You have ${parts.join(' and ')}. You cannot change your answers after submitting.`
      : 'All questions answered. You cannot change your answers after submitting.',
    okLabel: 'Submit exam',
    danger: unanswered > 0,
  });
  if (ok) submitExam('submitted');
});

async function submitExam(reason) {
  if (S.finished || S.aborted) return;
  S.finished = true;
  clearInterval(S.timerId);

  const btn = $('#submitBtn');
  btn.disabled = true;
  btn.textContent = 'Submitting…';

  try {
    await writeChain.catch(() => {});          // let queued answers land first
    // send the complete answer set as the authoritative record — the score
    // is computed from exactly what the candidate chose, never a lost write
    const data = await api('candidate/submit', {
      token: S.token, reason, answers: S.answers, flags: S.flags,
    });
    endExam(data.status, data.result);
  } catch (err) {
    if (err.message === 'reset') return;
    S.finished = false;                     // let them retry
    btn.disabled = false;
    btn.textContent = 'Submit';
    clearInterval(S.timerId);
    startTimer();
    toast(`Submit failed: ${err.message}. Please try again.`, 'err');
  }
}

function endExam(status, result) {
  S.finished = true;
  clearInterval(S.timerId);
  clearInterval(S.identTimer);
  S.lock && S.lock.stop();
  $('#fsBanner').classList.add('hidden');
  showResult({ status, violations: S.violations }, result);
}

/* ═══════════════ RESULT ═══════════════ */

function showResult(attempt, result) {
  show('resultView');
  const terminated = attempt.status === 'terminated';

  $('#resultIcon').textContent = terminated ? '⛔' : (result?.passed ? '🏆' : '📄');
  $('#resultHeading').textContent = terminated
    ? 'Exam terminated'
    : (result?.passed ? 'Congratulations — you passed!' : 'Exam submitted');
  $('#resultMsg').textContent = terminated
    ? 'Your exam was ended automatically after too many safe-mode violations. Your answers up to that point were recorded.'
    : 'Your responses have been recorded.';

  const box = $('#resultScoreBox');
  box.innerHTML = '';

  if (result) {
    box.append(
      el('div', { class: 'score-ring', style: `color:${result.passed ? 'var(--green)' : 'var(--orange)'}` }, `${result.percent}%`),
      el('p', { class: 'muted', style: 'margin-top:4px;' }, `${result.score} / ${result.total} marks`),
      el('div', { class: 'stat-grid', style: 'margin-top:18px;' }, [
        statTile(result.correct, 'Correct'),
        statTile(result.wrong, 'Wrong'),
        statTile(result.skipped, 'Skipped'),
      ]),
    );
  } else {
    box.append(el('p', { class: 'muted' }, 'Your examiner will share your result.'));
  }

  if (attempt.violations) {
    box.append(el('p', { style: 'margin-top:16px;font-size:0.82rem;color:#fca5a5;' },
      `⚠ ${attempt.violations} safe-mode violation(s) were logged during your exam.`));
  }
}

function statTile(n, l) {
  return el('div', { class: 'stat' }, [el('div', { class: 'n' }, String(n)), el('div', { class: 'l' }, l)]);
}

/* warn if the candidate tries to leave mid-exam */
window.addEventListener('beforeunload', (e) => {
  if (S.begun && !S.finished && !S.aborted) {
    e.preventDefault();
    e.returnValue = '';
  }
});

show('loginView');
