/* ===========================================================
   Star Ai Exam Suite — lockdown.js
   The "safe browser" layer. Web lockdown can be defeated by a
   determined user with a second device, so treat this as a
   deterrent + honest violation log, not a guarantee.

   It watches for: leaving fullscreen, switching tab/window,
   copy/paste/cut, right-click, text selection, printing, and a
   set of risky keyboard shortcuts. Each trip fires onViolation.
   =========================================================== */

export function createLockdown({ maxViolations = 3, onViolation, onTerminate } = {}) {
  let active = false;
  let violations = 0;
  const log = [];
  const handlers = [];

  function on(target, type, fn, opts) {
    target.addEventListener(type, fn, opts);
    handlers.push(() => target.removeEventListener(type, fn, opts));
  }

  function trip(reason) {
    if (!active) return;
    violations++;
    const entry = { reason, at: new Date().toISOString(), count: violations };
    log.push(entry);
    onViolation && onViolation(entry, violations, maxViolations);
    if (violations >= maxViolations) {
      onTerminate && onTerminate([...log]);
      stop();
    }
  }

  /* ── fullscreen ──────────────────────────────────────── */

  async function requestFullscreen() {
    const el = document.documentElement;
    try {
      if (el.requestFullscreen) await el.requestFullscreen();
      else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();
    } catch {
      /* browser refused — candidate can retry via the banner */
    }
  }

  function isFullscreen() {
    return !!(document.fullscreenElement || document.webkitFullscreenElement);
  }

  async function exitFullscreen() {
    try {
      if (document.exitFullscreen) await document.exitFullscreen();
      else if (document.webkitExitFullscreen) await document.webkitExitFullscreen();
    } catch {
      /* ignore */
    }
  }

  /* ── blocked shortcuts ───────────────────────────────── */

  const BLOCKED = [
    // copy / paste / cut / select-all / save / print / find
    (e) => (e.ctrlKey || e.metaKey) && ['c', 'v', 'x', 'a', 's', 'p', 'f', 'u'].includes(e.key.toLowerCase()),
    // devtools
    (e) => e.key === 'F12',
    (e) => (e.ctrlKey || e.metaKey) && e.shiftKey && ['i', 'j', 'c'].includes(e.key.toLowerCase()),
    // new tab / new window / close
    (e) => (e.ctrlKey || e.metaKey) && ['t', 'n', 'w'].includes(e.key.toLowerCase()),
  ];

  function onKeydown(e) {
    if (!active) return;
    for (const rule of BLOCKED) {
      if (rule(e)) {
        e.preventDefault();
        e.stopPropagation();
        trip(`Blocked shortcut: ${describeCombo(e)}`);
        return false;
      }
    }
  }

  function describeCombo(e) {
    const parts = [];
    if (e.ctrlKey) parts.push('Ctrl');
    if (e.metaKey) parts.push('Meta');
    if (e.shiftKey) parts.push('Shift');
    if (e.altKey) parts.push('Alt');
    parts.push(e.key.toUpperCase());
    return parts.join('+');
  }

  /* ── lifecycle ───────────────────────────────────────── */

  async function start() {
    if (active) return;
    active = true;
    violations = 0;
    log.length = 0;

    await requestFullscreen();

    on(document, 'visibilitychange', () => {
      if (document.hidden) trip('Switched away from the exam tab');
    });
    on(window, 'blur', () => trip('Exam window lost focus'));
    on(document, 'contextmenu', (e) => {
      e.preventDefault();
      trip('Right-click menu');
    });
    on(document, 'copy', (e) => { e.preventDefault(); trip('Copy attempt'); });
    on(document, 'cut', (e) => { e.preventDefault(); trip('Cut attempt'); });
    on(document, 'paste', (e) => { e.preventDefault(); trip('Paste attempt'); });
    on(window, 'beforeprint', () => trip('Print attempt'));
    on(document, 'keydown', onKeydown, true);
    on(document, 'fullscreenchange', () => {
      if (active && !isFullscreen()) trip('Left fullscreen mode');
    });
    on(document, 'selectstart', (e) => {
      // allow selecting inside inputs/textareas the candidate types in
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
      e.preventDefault();
    });
  }

  function stop() {
    active = false;
    while (handlers.length) handlers.pop()();
    exitFullscreen();
  }

  return {
    start,
    stop,
    requestFullscreen,
    isFullscreen,
    get violations() { return violations; },
    get log() { return [...log]; },
    get active() { return active; },
  };
}
