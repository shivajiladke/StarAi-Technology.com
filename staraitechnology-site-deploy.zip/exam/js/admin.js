/* ===========================================================
   Star Ai Exam Suite — admin.js
   Admin panel: PIN gate, exam builder, candidate codes, results.
   =========================================================== */

import * as store from './store.js';
import { $, el, esc, toast, confirmModal, fmtDate } from './ui.js';

/* ── auth gate ───────────────────────────────────────── */

function lock() {
  store.logout();
  location.reload();
}

async function showApp() {
  $('#loginView').classList.add('hidden');
  $('#appView').classList.remove('hidden');
  $('#logoutBtn').classList.remove('hidden');
  try {
    await store.connect();
  } catch (err) {
    if (err.status === 401) { store.logout(); location.reload(); return; }
    toast(`Could not load: ${err.message}`, 'err');
  }
  applyIdentity();
  renderExams();
  renderResults();
  renderAdmins();
  renderSettings();
}

/* Show who's signed in, and reveal only the tabs their role/permissions
   allow. The server enforces these too — this just keeps the UI honest. */
function applyIdentity() {
  const me = store.me() || {};
  const chip = $('#whoChip');
  chip.textContent = `${me.displayName || me.username || 'admin'} · ${me.role === 'master' ? 'Master' : 'Admin'}`;

  document.querySelectorAll('#tabBar .tab').forEach((t) => {
    let show = true;
    if (t.dataset.master) show = !!me.canManageAdmins;
    else if (t.dataset.perm) show = store.can(t.dataset.perm);
    t.classList.toggle('hidden', !show);
  });

  // if the active tab got hidden, fall back to Exams
  const active = document.querySelector('#tabBar .tab.active');
  if (active && active.classList.contains('hidden')) selectTab('exams');
}

function selectTab(name) {
  document.querySelectorAll('#tabBar .tab').forEach((x) => x.classList.toggle('active', x.dataset.tab === name));
  ['exams', 'results', 'admins', 'settings'].forEach((n) => {
    $(`#tab-${n}`).classList.toggle('hidden', n !== name);
  });
  if (name === 'results') store.refreshAttempts().then(renderResults).catch(() => renderResults());
  if (name === 'admins') renderAdmins();
}

$('#loginBtn').addEventListener('click', tryLogin);
$('#userInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#passInput').focus(); });
$('#passInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') tryLogin(); });
$('#logoutBtn').addEventListener('click', lock);

async function tryLogin() {
  const btn = $('#loginBtn');
  const username = $('#userInput').value.trim();
  const password = $('#passInput').value;
  if (!username || !password) { toast('Enter your username and password', 'err'); return; }
  btn.disabled = true;
  try {
    await store.login(username, password);
    await showApp();
  } catch (err) {
    toast(err.status === 401 ? 'Incorrect username or password'
      : err.status === 403 ? err.message
        : `Sign-in failed: ${err.message}`, 'err');
    $('#passInput').value = '';
  } finally {
    btn.disabled = false;
  }
}

/* ── tab switching ───────────────────────────────────── */

document.querySelectorAll('#tabBar .tab').forEach((t) => {
  t.addEventListener('click', () => selectTab(t.dataset.tab));
});

/* ═══════════════════════════════════════════════════════
   EXAMS TAB
   ═══════════════════════════════════════════════════════ */

let editingExamId = null; // null = list view

function renderExams() {
  const host = $('#tab-exams');
  host.innerHTML = '';
  if (editingExamId) {
    host.append(examEditor(store.getExam(editingExamId)));
  } else {
    host.append(examList());
  }
}

function examList() {
  const canExams = store.can('exams');
  const canCands = store.can('candidates');
  const exams = store.listExams();
  const frag = el('div', {}, [
    el('div', { class: 'card-hd', style: 'margin-bottom:18px;' }, [
      el('div', {}, [
        el('h3', { style: 'font-size:1.2rem;' }, 'Exam Papers'),
        el('p', { class: 'muted', style: 'font-size:0.85rem;' },
          canExams ? 'Create and manage MCQ exams.' : 'Issue and manage access codes for these exams.'),
      ]),
      canExams ? el('button', { class: 'btn btn-primary', onclick: createExam }, '＋ New Exam') : null,
    ]),
  ]);

  if (!exams.length) {
    frag.append(el('div', { class: 'card' }, [
      el('div', { class: 'empty' }, [
        el('div', { class: 'ico' }, '📝'),
        el('div', {}, 'No exams yet. Create your first MCQ paper.'),
      ]),
    ]));
    return frag;
  }

  for (const exam of exams) {
    const cands = store.listCandidates(exam.id);
    const done = store.listAttempts(exam.id).filter((a) => a.status === 'submitted').length;
    frag.append(el('div', { class: 'card' }, [
      el('div', { class: 'spread row wrap-row', style: 'align-items:flex-start;gap:14px;' }, [
        el('div', { class: 'grow' }, [
          el('div', { class: 'row', style: 'gap:9px;' }, [
            el('h3', {}, exam.title),
            statusPill(exam.status),
          ]),
          el('p', { class: 'muted', style: 'font-size:0.86rem;margin-top:4px;' },
            `${exam.questions.length} questions · ${store.examTotalMarks(exam)} marks · ${exam.durationMin} min · pass ${exam.passPercent}%`),
          el('p', { class: 'muted', style: 'font-size:0.8rem;margin-top:6px;' },
            `${cands.length} candidate code(s) · ${done} submitted`),
        ]),
        el('div', { class: 'row wrap-row', style: 'gap:8px;' }, [
          el('button', { class: 'btn btn-ghost btn-sm', onclick: () => { editingExamId = exam.id; renderExams(); } },
            canExams ? '✏️ Edit' : '🎟️ Codes'),
          canExams ? el('button', {
            class: `btn btn-sm ${exam.status === 'published' ? 'btn-ghost' : 'btn-orange'}`,
            onclick: () => togglePublish(exam.id),
          }, exam.status === 'published' ? 'Unpublish' : 'Publish') : null,
          canExams ? el('button', { class: 'btn btn-danger btn-sm', onclick: () => removeExam(exam.id) }, '🗑') : null,
        ]),
      ]),
    ]));
  }
  return frag;
}

function statusPill(status) {
  const map = {
    draft: ['pill-gray', 'Draft'],
    published: ['pill-green', 'Published'],
  };
  const [cls, label] = map[status] || map.draft;
  return el('span', { class: `pill ${cls}` }, label);
}

function createExam() {
  const exam = store.blankExam();
  store.saveExam(exam);
  editingExamId = exam.id;
  renderExams();
}

async function removeExam(id) {
  const ok = await confirmModal({
    title: 'Delete exam?',
    body: 'This removes the paper, its candidate codes and all attempts. This cannot be undone.',
    okLabel: 'Delete',
    danger: true,
  });
  if (!ok) return;
  store.deleteExam(id);
  toast('Exam deleted');
  renderExams();
}

function togglePublish(id) {
  const exam = store.getExam(id);

  if (exam.status !== 'published') {
    const issues = store.validateExam(exam);
    if (issues.length) { showIssues(exam, issues); return; }
  }

  exam.status = exam.status === 'published' ? 'draft' : 'published';
  store.saveExam(exam);
  toast(exam.status === 'published' ? 'Exam published' : 'Exam unpublished', 'ok');
  renderExams();
}

/* Publishing a broken paper is worse than blocking it, so spell out
   exactly what needs fixing rather than a one-line toast. */
function showIssues(exam, issues) {
  const host = el('div', { class: 'modal-host', onclick: (e) => { if (e.target === host) host.remove(); } }, [
    el('div', { class: 'modal' }, [
      el('h3', { style: 'font-size:1.15rem;margin-bottom:4px;' }, 'Cannot publish yet'),
      el('p', { class: 'muted', style: 'font-size:0.86rem;margin-bottom:14px;' },
        `“${exam.title}” has ${issues.length} problem${issues.length === 1 ? '' : 's'} to fix first:`),
      el('ul', { style: 'padding-left:18px;display:flex;flex-direction:column;gap:6px;' },
        issues.map((i) => el('li', { style: 'font-size:0.87rem;color:#fca5a5;' }, i))),
      el('div', { class: 'row', style: 'justify-content:flex-end;margin-top:18px;gap:8px;' }, [
        el('button', { class: 'btn btn-ghost', onclick: () => host.remove() }, 'Close'),
        el('button', { class: 'btn btn-primary', onclick: () => { host.remove(); editingExamId = exam.id; renderExams(); } }, 'Fix now'),
      ]),
    ]),
  ]);
  document.body.append(host);
}

/* ── exam editor ─────────────────────────────────────── */

function examEditor(exam) {
  const canExams = store.can('exams');
  const canCands = store.can('candidates');

  const frag = el('div', {}, [
    el('div', { class: 'row', style: 'margin-bottom:18px;gap:10px;' }, [
      el('button', { class: 'btn btn-ghost btn-sm', onclick: () => { editingExamId = null; renderExams(); } }, '← Back'),
      el('h3', { style: 'font-size:1.2rem;' }, canExams ? 'Edit Exam' : exam.title),
      statusPill(exam.status),
    ]),
  ]);

  /* Paper settings + questions — only for admins who may edit exams.
     A candidates-only admin sees just the codes card below. */
  if (canExams) {
    const bind = (prop, transform = (v) => v) => (e) => {
      exam[prop] = transform(e.target.type === 'checkbox' ? e.target.checked : e.target.value);
      store.saveExam(exam);
    };
    const num = (v) => Number(v) || 0;

    const titleInput = input('text', exam.title, bind('title'));
    const descBox = textarea(exam.description, bind('description'));

    const qCard = el('div', { class: 'card' });
    const rerenderQuestions = () => { qCard.innerHTML = ''; qCard.append(...questionsSection(exam, rerenderQuestions)); };

    frag.append(el('div', { class: 'card' }, [
      el('div', { class: 'card-hd' }, [el('h3', {}, 'Paper settings')]),
      labeled('Title', titleInput),
      aiPanel(exam, titleInput, descBox, () => rerenderQuestions()),
      labeled('Description', descBox),
      el('div', { class: 'field-row' }, [
        labeled('Duration (min)', input('number', exam.durationMin, bind('durationMin', num))),
        labeled('Pass %', input('number', exam.passPercent, bind('passPercent', num))),
      ]),
      el('div', { class: 'field-row' }, [
        labeled('Negative mark / wrong', input('number', exam.negativeMark, bind('negativeMark', num), { step: '0.25' })),
        labeled('Max violations before auto-submit', input('number', exam.maxViolations, bind('maxViolations', num))),
      ]),
      el('div', { class: 'stack', style: 'margin-top:6px;gap:10px;' }, [
        checkbox('Shuffle question order', exam.shuffleQuestions, bind('shuffleQuestions')),
        checkbox('Shuffle option order', exam.shuffleOptions, bind('shuffleOptions')),
        checkbox('Show score to candidate after submit', exam.showResultToCandidate, bind('showResultToCandidate')),
      ]),
    ]));

    rerenderQuestions();
    frag.append(qCard);
  }

  /* candidate codes card — only for admins who may manage candidates */
  if (canCands) frag.append(candidatesCard(exam));

  return frag;
}

/* ── AI authoring ─────────────────────────────────────────
   Deliberately a button rather than firing on every title edit:
   generation costs money, takes ~a minute, and appends to whatever
   is already there — not something to trigger on a keystroke. */

const AI_BATCH = 10;   // matches the server's per-request cap

function aiPanel(exam, titleInput, descBox, rerenderQuestions) {
  if (!(store.me() && store.me().aiEnabled)) return null;

  const countInput = el('input', {
    type: 'number', value: 50, min: '1', max: '200',
    style: 'width:78px;padding:8px 10px;',
  });

  const status = el('div', { class: 'ai-status hidden' });
  const bar = el('div', { class: 'ai-bar' }, [el('span', {})]);
  const fill = bar.firstChild;

  let running = false;
  let cancelled = false;

  const genBtn = el('button', { class: 'btn btn-orange btn-sm', onclick: () => run() },
    '✨ Generate with AI');
  const stopBtn = el('button', { class: 'btn btn-ghost btn-sm hidden', onclick: () => { cancelled = true; } },
    'Stop');

  const setStatus = (msg, pct) => {
    status.classList.remove('hidden');
    status.textContent = msg;
    if (pct !== undefined) fill.style.width = `${Math.max(0, Math.min(100, pct))}%`;
  };

  async function run() {
    if (running) return;

    const title = titleInput.value.trim();
    if (!title || title === 'Untitled Exam') {
      toast('Enter a real exam title first', 'err');
      titleInput.focus();
      return;
    }

    const target = Math.max(1, Math.min(200, Number(countInput.value) || 50));

    if (exam.questions.length) {
      const ok = await confirmModal({
        title: 'Add to the existing questions?',
        body: `This paper already has ${exam.questions.length} question(s). `
          + `${target} generated question(s) will be added after them — nothing is replaced.`,
        okLabel: 'Generate and add',
      });
      if (!ok) return;
    }

    running = true; cancelled = false;
    genBtn.disabled = true;
    countInput.disabled = true;
    stopBtn.classList.remove('hidden');
    bar.classList.remove('hidden');

    try {
      // description first — cheap, and it confirms the key works before
      // committing to a minute of question generation
      if (!exam.description.trim()) {
        setStatus('Writing the description…', 2);
        exam.description = await store.aiDescription(title);
        descBox.value = exam.description;
        store.saveExam(exam);
      }

      const added = [];
      // seeded with existing text so the model doesn't re-ask what's already there
      const avoid = exam.questions.map((q) => q.text).filter(Boolean);

      while (added.length < target && !cancelled) {
        const want = Math.min(AI_BATCH, target - added.length);
        setStatus(`Writing questions… ${added.length} of ${target}`,
          5 + (added.length / target) * 95);

        const batch = await store.aiQuestions(title, want, avoid);
        if (!batch.length) throw new Error('The model returned no usable questions.');

        for (const q of batch) {
          if (added.length >= target) break;
          const nq = store.blankQuestion();
          nq.text = q.text;
          nq.options = q.options;
          nq.correct = q.correct;
          nq.marks = q.marks ?? 1;
          exam.questions.push(nq);
          avoid.push(q.text);
          added.push(nq);
        }

        store.saveExam(exam);          // persist each batch, so a later
        rerenderQuestions();           // failure never loses earlier work
      }

      setStatus(cancelled
        ? `Stopped — ${added.length} question(s) added.`
        : `Done — ${added.length} question(s) added.`, 100);
      toast(`${added.length} question(s) generated`, 'ok');
    } catch (err) {
      setStatus(`Generation failed: ${err.message}`, 0);
      toast(err.message, 'err');
    } finally {
      running = false;
      genBtn.disabled = false;
      countInput.disabled = false;
      stopBtn.classList.add('hidden');
      await store.flush().catch(() => {});
    }
  }

  return el('div', { class: 'ai-panel' }, [
    el('div', { class: 'row wrap-row' }, [
      el('div', { class: 'grow' }, [
        el('b', { style: 'font-size:0.88rem;' }, '✨ Generate from the title'),
        el('p', { class: 'muted', style: 'font-size:0.8rem;margin-top:2px;' },
          'Writes the description and a full set of MCQs based on the exam title. Review before publishing.'),
      ]),
      el('label', { class: 'row', style: 'gap:7px;font-size:0.82rem;color:var(--muted);' },
        ['Questions', countInput]),
      genBtn,
      stopBtn,
    ]),
    bar,
    status,
  ]);
}

/* ── answer key (admin only) ──────────────────────────────
   The key lives server-side and is stripped from anything a
   candidate receives — this view just surfaces it for the admin
   to review or print. Results are declared by matching each
   submission against exactly these answers, server-side. */
function showAnswerKey(exam) {
  const letter = (i) => String.fromCharCode(65 + i);

  const rows = exam.questions.map((q, i) => el('tr', {}, [
    el('td', { style: 'font-weight:700;color:var(--muted);' }, `Q${i + 1}`),
    el('td', { style: 'white-space:normal;max-width:420px;' }, q.text || '(no text)'),
    el('td', {}, [
      el('span', { class: 'pill pill-green' }, letter(q.correct)),
      el('span', { style: 'margin-left:8px;' }, q.options[q.correct] ?? '—'),
    ]),
    el('td', {}, String(q.marks ?? 1)),
  ]));

  const host = el('div', { class: 'modal-host', onclick: (e) => { if (e.target === host) host.remove(); } }, [
    el('div', { class: 'modal', style: 'max-width:720px;width:100%;' }, [
      el('div', { class: 'spread row' }, [
        el('h3', { style: 'font-size:1.2rem;' }, `🔑 Answer key — ${esc(exam.title)}`),
        el('button', { class: 'btn btn-ghost btn-sm', onclick: () => host.remove() }, '✕'),
      ]),
      el('p', { style: 'font-size:0.82rem;color:#fcd34d;background:rgba(245,158,11,0.09);border:1px solid rgba(245,158,11,0.3);border-radius:11px;padding:10px 12px;margin:8px 0 14px;' },
        '🔒 Admin only. Candidates never receive the answer key — the exam sent to them contains no correct-answer data, and results are scored against this key on the server.'),
      el('div', { class: 'tbl-wrap' }, [
        el('table', {}, [
          el('thead', {}, [el('tr', {}, ['#', 'Question', 'Correct answer', 'Marks'].map((h) => el('th', {}, h)))]),
          el('tbody', {}, rows),
        ]),
      ]),
      el('div', { class: 'row', style: 'justify-content:flex-end;margin-top:16px;gap:8px;' }, [
        el('button', { class: 'btn btn-ghost', onclick: () => exportAnswerKeyCsv(exam) }, '⇩ Export key (CSV)'),
        el('button', { class: 'btn btn-primary', onclick: () => host.remove() }, 'Close'),
      ]),
    ]),
  ]);
  document.body.append(host);
}

function exportAnswerKeyCsv(exam) {
  const letter = (i) => String.fromCharCode(65 + i);
  const lines = [['#', 'Question', 'Correct option', 'Correct answer', 'Marks'].join(',')];
  exam.questions.forEach((q, i) => {
    const cells = [i + 1, q.text ?? '', letter(q.correct), q.options[q.correct] ?? '', q.marks ?? 1]
      .map((c) => `"${String(c).replace(/"/g, '""')}"`);
    lines.push(cells.join(','));
  });
  downloadFile(`answer-key-${exam.title.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.csv`, lines.join('\n'), 'text/csv');
  toast('Answer key exported', 'ok');
}

function questionsSection(exam, rerender) {
  const head = el('div', { class: 'card-hd' }, [
    el('div', {}, [
      el('h3', {}, `Questions (${exam.questions.length})`),
      el('p', { class: 'muted', style: 'font-size:0.82rem;' }, 'Pick the green radio for the correct option.'),
    ]),
    el('div', { class: 'row wrap-row', style: 'gap:8px;' }, [
      exam.questions.length
        ? el('button', { class: 'btn btn-ghost btn-sm', onclick: () => showAnswerKey(exam) }, '🔑 Answer key')
        : null,
      exam.questions.length
        ? el('button', { class: 'btn btn-ghost btn-sm', onclick: () => importAnswerKey(exam, rerender) }, '⇪ Import key')
        : null,
      el('button', { class: 'btn btn-ghost btn-sm', onclick: () => importQuestions(exam, rerender) }, '⇪ Bulk import'),
      el('button', { class: 'btn btn-primary btn-sm', onclick: () => { exam.questions.push(store.blankQuestion()); store.saveExam(exam); rerender(); } }, '＋ Question'),
    ]),
  ]);

  const nodes = [head];

  if (!exam.questions.length) {
    nodes.push(el('div', { class: 'empty' }, [el('div', { class: 'ico' }, '❓'), el('div', {}, 'No questions yet.')]));
    return nodes;
  }

  exam.questions.forEach((q, qi) => {
    const correctIdx = q.correct;
    const saveQ = () => store.saveExam(exam);

    const optionRows = q.options.map((opt, oi) => el('div', { class: 'opt-edit' }, [
      el('input', {
        type: 'radio', name: `correct-${q.id}`, checked: oi === correctIdx ? 'checked' : null,
        onchange: () => { q.correct = oi; saveQ(); },
        title: 'Mark as correct answer',
      }),
      el('input', {
        type: 'text', value: opt, placeholder: `Option ${oi + 1}`, class: 'grow',
        oninput: (e) => { q.options[oi] = e.target.value; saveQ(); },
      }),
      q.options.length > 2 ? el('button', {
        class: 'btn btn-danger btn-sm', title: 'Remove option',
        onclick: () => {
          q.options.splice(oi, 1);
          const cur = q.correct;
          if (cur === oi) q.correct = 0;
          else if (cur > oi) q.correct = cur - 1;
          saveQ(); rerender();
        },
      }, '✕') : null,
    ]));

    const qText = el('textarea', { placeholder: 'Question text…', class: 'grow', style: 'margin-bottom:10px;', oninput: (e) => { q.text = e.target.value; saveQ(); } });
    qText.value = q.text;

    nodes.push(el('div', { class: 'q-edit' }, [
      el('div', { class: 'q-edit-hd' }, [
        el('span', { class: 'q-num' }, `Q${qi + 1}`),
        el('div', { class: 'row', style: 'gap:8px;' }, [
          el('label', { class: 'row', style: 'gap:6px;font-size:0.8rem;color:var(--muted);' }, [
            'Marks',
            el('input', { type: 'number', value: q.marks, style: 'width:64px;padding:6px 8px;', oninput: (e) => { q.marks = Number(e.target.value) || 0; saveQ(); } }),
          ]),
          el('button', { class: 'btn btn-danger btn-sm', onclick: async () => {
            if (!(await confirmModal({ title: 'Delete question?', okLabel: 'Delete', danger: true }))) return;
            exam.questions.splice(qi, 1); saveQ(); rerender();
          } }, '🗑'),
        ]),
      ]),
      qText,
      ...optionRows,
      q.options.length < 6 ? el('button', {
        class: 'btn btn-ghost btn-sm', style: 'margin-top:4px;',
        onclick: () => { q.options.push(''); saveQ(); rerender(); },
      }, '＋ Add option') : null,
    ]));
  });

  return nodes;
}

/* bulk import: "Question | optA | optB | optC | optD | correctIndex(1-based)" per line */
async function importQuestions(exam, rerender) {
  const sample = 'What is 2+2? | 3 | 4 | 5 | 6 | 2\nCapital of France? | London | Paris | Rome | 2';
  const ta = el('textarea', { style: 'min-height:180px;font-family:monospace;font-size:0.82rem;', placeholder: sample });
  const host = el('div', { class: 'modal-host' }, [
    el('div', { class: 'modal' }, [
      el('h3', { style: 'font-size:1.15rem;margin-bottom:6px;' }, 'Bulk import questions'),
      el('p', { class: 'muted', style: 'font-size:0.83rem;margin-bottom:12px;' },
        'One question per line, pipe-separated: text | option1 | option2 | … | correctNumber. The last field is the correct option number (1-based).'),
      ta,
      el('div', { class: 'row', style: 'justify-content:flex-end;margin-top:14px;gap:8px;' }, [
        el('button', { class: 'btn btn-ghost', onclick: () => host.remove() }, 'Cancel'),
        el('button', { class: 'btn btn-primary', onclick: () => {
          const added = parseBulk(ta.value, exam);
          host.remove();
          if (added > 0) { store.saveExam(exam); rerender(); toast(`Imported ${added} question(s)`, 'ok'); }
          else toast('Nothing valid to import', 'err');
        } }, 'Import'),
      ]),
    ]),
  ]);
  document.body.append(host);
}

function parseBulk(raw, exam) {
  let added = 0;
  for (const line of raw.split('\n')) {
    const parts = line.split('|').map((s) => s.trim());
    if (parts.length < 4) continue;
    const correct = Number(parts[parts.length - 1]);
    const options = parts.slice(1, -1);
    const text = parts[0];
    if (!text || options.length < 2 || !Number.isInteger(correct) || correct < 1 || correct > options.length) continue;
    const q = store.blankQuestion();
    q.text = text;
    q.options = options;
    q.correct = correct - 1;
    exam.questions.push(q);
    added++;
  }
  return added;
}

/* ── bulk import answer key ───────────────────────────────
   Applies correct answers to questions that already exist, matched
   by question number. Lets an admin paste MCQs (unanswered) first
   and set the whole key in one step. Answers can be letters (A–F)
   or 1-based option numbers; separators are flexible. */
function importAnswerKey(exam, rerender) {
  const n = exam.questions.length;
  const sample = `1-B\n2-C\n3-A\n…up to Q${n}`;
  const ta = el('textarea', {
    style: 'min-height:170px;font-family:monospace;font-size:0.82rem;',
    placeholder: sample,
  });
  const report = el('div', { style: 'font-size:0.82rem;margin-top:10px;' });

  const host = el('div', { class: 'modal-host', onclick: (e) => { if (e.target === host) host.remove(); } }, [
    el('div', { class: 'modal' }, [
      el('h3', { style: 'font-size:1.15rem;margin-bottom:6px;' }, 'Import answer key'),
      el('p', { class: 'muted', style: 'font-size:0.83rem;margin-bottom:6px;' },
        `Set correct answers for the ${n} existing question(s) by number. `
        + 'Use letters (A–F) or option numbers (1–6). One per line, or comma/space separated:'),
      el('p', { class: 'muted', style: 'font-size:0.8rem;font-family:monospace;margin-bottom:12px;' },
        '1-B, 2-C, 3-A   ·   1) B   ·   Q1 B   ·   or just: B C A D …'),
      ta,
      report,
      el('div', { class: 'row', style: 'justify-content:flex-end;margin-top:14px;gap:8px;' }, [
        el('button', { class: 'btn btn-ghost', onclick: () => host.remove() }, 'Cancel'),
        el('button', { class: 'btn btn-ghost', onclick: () => {
          const { applied, issues } = parseAnswerKey(ta.value, exam, true); // dry run
          showKeyReport(report, applied, issues, n, true);
        } }, 'Preview'),
        el('button', { class: 'btn btn-primary', onclick: () => {
          const { applied, issues } = parseAnswerKey(ta.value, exam, false); // apply
          if (applied > 0) { store.saveExam(exam); rerender(); }
          showKeyReport(report, applied, issues, n, false);
          if (applied > 0) toast(`Applied ${applied} answer(s)`, 'ok');
          else toast('No answers applied', 'err');
        } }, 'Apply key'),
      ]),
    ]),
  ]);
  document.body.append(host);
}

function showKeyReport(host, applied, issues, total, isPreview) {
  host.innerHTML = '';
  const verb = isPreview ? 'would set' : 'set';
  host.append(el('div', { style: `color:${applied ? '#86efac' : 'var(--muted)'};` },
    `✓ ${verb} ${applied} of ${total} answer(s).`));
  if (issues.length) {
    host.append(el('ul', { style: 'padding-left:18px;margin-top:6px;color:#fca5a5;display:flex;flex-direction:column;gap:3px;' },
      issues.slice(0, 12).map((i) => el('li', {}, i))));
    if (issues.length > 12) host.append(el('div', { class: 'muted', style: 'margin-top:4px;' }, `…and ${issues.length - 12} more.`));
  }
}

/* Returns { applied, issues }. When dryRun, computes without mutating. */
function parseAnswerKey(raw, exam, dryRun) {
  const n = exam.questions.length;
  const issues = [];

  // Two accepted shapes:
  //  (a) numbered  — "1-B", "2) C", "Q3 A", "4: 2"   (any order, any subset)
  //  (b) sequence  — "B C A D" / "B,C,A,D"           (position = question number)
  const tokens = raw.split(/[\n,;]+/).map((s) => s.trim()).filter(Boolean);
  const numbered = [];
  let hasNumberPrefix = false;

  for (const tok of tokens) {
    const m = tok.match(/^(?:q\s*)?(\d+)\s*[).:\-\s]\s*([A-Fa-f]|\d+)$/);
    if (m) {
      hasNumberPrefix = true;
      numbered.push([Number(m[1]), m[2]]);
    }
  }

  const assignments = new Map(); // qIndex(0-based) -> answer token

  if (hasNumberPrefix) {
    for (const [qNum, ans] of numbered) {
      if (qNum < 1 || qNum > n) { issues.push(`Q${qNum}: no such question (paper has ${n}).`); continue; }
      assignments.set(qNum - 1, ans);
    }
  } else {
    // bare sequence: one answer per whitespace-separated token, in order
    const seq = raw.split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean);
    if (seq.length > n) issues.push(`Got ${seq.length} answers but the paper has only ${n} question(s) — extras ignored.`);
    seq.slice(0, n).forEach((ans, i) => {
      if (!/^([A-Fa-f]|\d+)$/.test(ans)) { issues.push(`Q${i + 1}: "${ans}" is not a letter or option number.`); return; }
      assignments.set(i, ans);
    });
  }

  let applied = 0;
  for (const [qi, ans] of assignments) {
    const q = exam.questions[qi];
    const idx = answerToIndex(ans, q.options.length);
    if (idx < 0) {
      issues.push(`Q${qi + 1}: "${ans}" is out of range (has ${q.options.length} options).`);
      continue;
    }
    if (!dryRun) q.correct = idx;
    applied++;
  }

  return { applied, issues };
}

/* Letter A→0, B→1… or 1-based number → 0-based index; -1 if out of range. */
function answerToIndex(ans, optCount) {
  const s = String(ans).trim();
  let idx;
  if (/^[A-Fa-f]$/.test(s)) idx = s.toUpperCase().charCodeAt(0) - 65;
  else if (/^\d+$/.test(s)) idx = Number(s) - 1;
  else return -1;
  return idx >= 0 && idx < optCount ? idx : -1;
}

/* ── candidate codes ─────────────────────────────────── */

function candidatesCard(exam) {
  const card = el('div', { class: 'card' });
  const rerender = () => { card.innerHTML = ''; card.append(...candidatesInner(exam, rerender)); };
  rerender();
  return card;
}

function candidatesInner(exam, rerender) {
  const cands = store.listCandidates(exam.id);
  const nameInput = el('input', { type: 'text', placeholder: 'Candidate name', class: 'grow' });

  const issue = (name) => {
    const cand = { id: store.uid('cand'), examId: exam.id, name, code: store.uniqueAccessCode(), createdAt: new Date().toISOString() };
    store.saveCandidate(cand);
    return cand;
  };

  const addOne = () => {
    const name = nameInput.value.trim();
    if (!name) { toast('Enter a name', 'err'); return; }
    issue(name);
    nameInput.value = '';
    rerender();
  };

  // Generate a code with no name attached — hand it out and fill the name later.
  const generateOne = () => {
    const n = cands.filter((c) => /^Candidate \d+$/.test(c.name)).length + 1;
    const cand = issue(`Candidate ${n}`);
    rerender();
    showCodeModal(exam, cand);
  };

  const head = el('div', { class: 'card-hd' }, [
    el('div', {}, [
      el('h3', {}, `Candidate codes (${cands.length})`),
      el('p', { class: 'muted', style: 'font-size:0.82rem;' }, 'Each candidate gets a unique code to log in.'),
    ]),
    el('div', { class: 'row', style: 'gap:8px;' }, [
      el('button', { class: 'btn btn-ghost btn-sm', onclick: () => bulkAddCandidates(exam, rerender) }, '⇪ Bulk add'),
      el('button', { class: 'btn btn-orange btn-sm', onclick: generateOne }, '⚡ Generate code'),
    ]),
  ]);

  const addRow = el('div', { class: 'row', style: 'gap:8px;margin-bottom:14px;' }, [
    nameInput,
    el('button', { class: 'btn btn-primary btn-sm', onclick: addOne }, '＋ Add'),
  ]);
  nameInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') addOne(); });

  const nodes = [head, addRow];

  if (!cands.length) {
    nodes.push(el('div', { class: 'empty', style: 'padding:20px;' }, 'No candidates yet.'));
    return nodes;
  }

  const rows = cands.map((c) => {
    const attempt = store.findAttemptByCandidate(c.id);
    const st = attempt ? attempt.status : 'not started';

    // name is editable in place, so a pre-generated code can be assigned later
    const nameCell = el('input', {
      type: 'text', value: c.name, style: 'padding:6px 9px;min-width:150px;',
      onchange: (e) => { c.name = e.target.value.trim() || c.name; store.saveCandidate(c); toast('Name updated', 'ok'); },
    });

    return el('tr', {}, [
      el('td', {}, [nameCell]),
      el('td', {}, [el('span', { class: 'code-pill' }, c.code)]),
      el('td', {}, [attemptPill(st)]),
      el('td', {}, [
        el('div', { class: 'row', style: 'gap:6px;' }, [
          el('button', { class: 'btn btn-ghost btn-sm', onclick: () => showCodeModal(exam, c) }, 'Show'),
          el('button', { class: 'btn btn-ghost btn-sm', onclick: () => { navigator.clipboard?.writeText(c.code); toast('Code copied', 'ok'); } }, 'Copy'),
          attempt ? el('button', { class: 'btn btn-ghost btn-sm', onclick: async () => {
            if (!(await confirmModal({ title: 'Reset attempt?', body: `Let ${esc(c.name)} retake the exam?`, okLabel: 'Reset' }))) return;
            try { await store.deleteAttempt(attempt.id); rerender(); toast('Attempt reset', 'ok'); }
            catch (err) { toast(`Reset failed: ${err.message}`, 'err'); }
          } }, 'Reset') : null,
          el('button', { class: 'btn btn-danger btn-sm', onclick: async () => {
            if (!(await confirmModal({ title: 'Remove candidate?', okLabel: 'Remove', danger: true }))) return;
            store.deleteCandidate(c.id); rerender();
          } }, '✕'),
        ]),
      ]),
    ]);
  });

  nodes.push(el('div', { class: 'tbl-wrap' }, [
    el('table', {}, [
      el('thead', {}, [el('tr', {}, [el('th', {}, 'Name'), el('th', {}, 'Code'), el('th', {}, 'Status'), el('th', {}, 'Actions')])]),
      el('tbody', {}, rows),
    ]),
  ]));
  return nodes;
}

/* Big, readable card for handing the code to a candidate. */
function showCodeModal(exam, cand) {
  const host = el('div', { class: 'modal-host', onclick: (e) => { if (e.target === host) host.remove(); } }, [
    el('div', { class: 'modal', style: 'text-align:center;max-width:420px;' }, [
      el('div', { style: 'font-size:2.2rem;' }, '🎟️'),
      el('h3', { style: 'font-size:1.2rem;margin:6px 0 2px;' }, 'Access code issued'),
      el('p', { class: 'muted', style: 'font-size:0.86rem;' }, `${cand.name} · ${exam.title}`),
      el('div', {
        class: 'code-pill',
        style: 'font-size:2.5rem;letter-spacing:9px;margin:20px 0 6px;display:block;',
      }, cand.code),
      el('p', { class: 'muted', style: 'font-size:0.82rem;margin-bottom:18px;' },
        `Exam opens for ${exam.durationMin} minutes once the candidate presses Start.`),
      el('div', { class: 'row', style: 'justify-content:center;gap:8px;' }, [
        el('button', { class: 'btn btn-primary', onclick: () => { navigator.clipboard?.writeText(cand.code); toast('Code copied', 'ok'); } }, 'Copy code'),
        el('button', { class: 'btn btn-ghost', onclick: () => host.remove() }, 'Close'),
      ]),
      exam.status !== 'published'
        ? el('p', { style: 'margin-top:14px;font-size:0.8rem;color:#fcd34d;' }, '⚠ This exam is still a draft — publish it before the candidate can log in.')
        : null,
    ]),
  ]);
  document.body.append(host);
}

function attemptPill(status) {
  const map = {
    'not started': ['pill-gray', 'Not started'],
    'in-progress': ['pill-amber', 'In progress'],
    submitted: ['pill-green', 'Submitted'],
    terminated: ['pill-red', 'Terminated'],
  };
  const [cls, label] = map[status] || map['not started'];
  return el('span', { class: `pill ${cls}` }, label);
}

async function bulkAddCandidates(exam, rerender) {
  const ta = el('textarea', { style: 'min-height:150px;', placeholder: 'One candidate name per line' });
  const host = el('div', { class: 'modal-host' }, [
    el('div', { class: 'modal' }, [
      el('h3', { style: 'font-size:1.15rem;margin-bottom:10px;' }, 'Bulk add candidates'),
      ta,
      el('div', { class: 'row', style: 'justify-content:flex-end;margin-top:14px;gap:8px;' }, [
        el('button', { class: 'btn btn-ghost', onclick: () => host.remove() }, 'Cancel'),
        el('button', { class: 'btn btn-primary', onclick: () => {
          let n = 0;
          for (const line of ta.value.split('\n')) {
            const name = line.trim();
            if (!name) continue;
            store.saveCandidate({ id: store.uid('cand'), examId: exam.id, name, code: store.uniqueAccessCode(), createdAt: new Date().toISOString() });
            n++;
          }
          host.remove();
          if (n) { rerender(); toast(`Added ${n} candidate(s)`, 'ok'); }
        } }, 'Add'),
      ]),
    ]),
  ]);
  document.body.append(host);
}

/* ═══════════════════════════════════════════════════════
   RESULTS TAB
   ═══════════════════════════════════════════════════════ */

function renderResults() {
  const host = $('#tab-results');
  host.innerHTML = '';

  const exams = store.listExams();
  const attempts = store.listAttempts().filter((a) => a.status === 'submitted' || a.status === 'terminated');

  const totalCands = store.listCandidates().length;
  const passed = attempts.filter((a) => a.result?.passed).length;

  host.append(el('div', { class: 'stat-grid', style: 'margin-bottom:20px;' }, [
    stat(exams.length, 'Exams'),
    stat(totalCands, 'Candidates'),
    stat(attempts.length, 'Submitted'),
    stat(attempts.length ? `${Math.round((passed / attempts.length) * 100)}%` : '—', 'Pass rate'),
  ]));

  if (!attempts.length) {
    host.append(el('div', { class: 'card' }, [el('div', { class: 'empty' }, [el('div', { class: 'ico' }, '📊'), el('div', {}, 'No submissions yet.')])]));
    return;
  }

  const rows = attempts
    .sort((a, b) => new Date(b.submittedAt || 0) - new Date(a.submittedAt || 0))
    .map((a) => {
      const cand = store.listCandidates().find((c) => c.id === a.candidateId);
      const exam = store.getExam(a.examId);
      const r = a.result || {};
      return el('tr', {}, [
        el('td', {}, cand ? cand.name : '—'),
        el('td', {}, exam ? exam.title : '—'),
        el('td', {}, `${r.score ?? 0} / ${r.total ?? 0}`),
        el('td', {}, [el('b', {}, `${r.percent ?? 0}%`)]),
        el('td', {}, [r.passed ? el('span', { class: 'pill pill-green' }, 'Pass') : el('span', { class: 'pill pill-red' }, 'Fail')]),
        el('td', {}, [attemptPill(a.status)]),
        el('td', {}, [el('span', { class: (a.violations?.length ? 'pill pill-amber' : 'pill pill-gray') }, String(a.violations?.length || 0))]),
        el('td', {}, fmtDate(a.submittedAt)),
        el('td', {}, [el('button', { class: 'btn btn-ghost btn-sm', onclick: () => showAttemptDetail(a) }, 'View')]),
      ]);
    });

  host.append(el('div', { class: 'card-hd' }, [
    el('h3', { style: 'font-size:1.15rem;' }, 'Submissions'),
    el('button', { class: 'btn btn-ghost btn-sm', onclick: exportResultsCsv }, '⇩ Export CSV'),
  ]));

  host.append(el('div', { class: 'tbl-wrap' }, [
    el('table', {}, [
      el('thead', {}, [el('tr', {}, ['Candidate', 'Exam', 'Score', '%', 'Result', 'Status', 'Flags', 'Submitted', ''].map((h) => el('th', {}, h)))]),
      el('tbody', {}, rows),
    ]),
  ]));
}

function showAttemptDetail(a) {
  const cand = store.listCandidates().find((c) => c.id === a.candidateId);
  const exam = store.getExam(a.examId);
  const r = a.result || {};

  const qReview = exam ? exam.questions.map((q, i) => {
    const given = a.answers[q.id];
    const key = q.correct;
    const ok = given === key;
    return el('div', { style: 'padding:10px 0;border-bottom:1px solid var(--border);' }, [
      el('div', { style: 'font-size:0.86rem;font-weight:600;margin-bottom:4px;' }, `Q${i + 1}. ${q.text || '(no text)'}`),
      el('div', { style: 'font-size:0.82rem;' }, [
        given === undefined
          ? el('span', { class: 'pill pill-gray' }, 'Skipped')
          : el('span', { class: `pill ${ok ? 'pill-green' : 'pill-red'}` }, ok ? 'Correct' : 'Wrong'),
        el('span', { class: 'muted', style: 'margin-left:8px;' },
          `answered: ${given === undefined ? '—' : esc(q.options[given] ?? '?')} · correct: ${esc(q.options[key] ?? '?')}`),
      ]),
    ]);
  }) : [];

  const violList = (a.violations || []).map((v) => el('li', { style: 'font-size:0.8rem;color:var(--muted);' }, `${fmtDate(v.at)} — ${esc(v.reason)}`));

  const host = el('div', { class: 'modal-host', onclick: (e) => { if (e.target === host) host.remove(); } }, [
    el('div', { class: 'modal' }, [
      el('div', { class: 'spread row' }, [
        el('h3', { style: 'font-size:1.2rem;' }, cand ? cand.name : 'Attempt'),
        el('button', { class: 'btn btn-ghost btn-sm', onclick: () => host.remove() }, '✕'),
      ]),
      el('p', { class: 'muted', style: 'font-size:0.85rem;margin:2px 0 14px;' }, exam ? exam.title : ''),
      el('div', { class: 'stat-grid', style: 'margin-bottom:16px;' }, [
        stat(`${r.score ?? 0}/${r.total ?? 0}`, 'Score'),
        stat(`${r.percent ?? 0}%`, 'Percent'),
        stat(r.correct ?? 0, 'Correct'),
        stat(r.wrong ?? 0, 'Wrong'),
      ]),
      violList.length ? el('div', { style: 'margin-bottom:14px;' }, [
        el('h4', { style: 'font-size:0.9rem;margin-bottom:6px;color:#fca5a5;' }, `⚠ Violations (${violList.length})`),
        el('ul', { style: 'padding-left:18px;' }, violList),
      ]) : null,
      el('h4', { style: 'font-size:0.9rem;margin-bottom:4px;' }, 'Answer review'),
      el('div', {}, qReview),
    ]),
  ]);
  document.body.append(host);
}

function exportResultsCsv() {
  const attempts = store.listAttempts().filter((a) => a.status === 'submitted' || a.status === 'terminated');
  const cands = store.listCandidates();
  const header = ['Candidate', 'Exam', 'Score', 'Total', 'Percent', 'Result', 'Status', 'Violations', 'Submitted'];
  const lines = [header.join(',')];
  for (const a of attempts) {
    const cand = cands.find((c) => c.id === a.candidateId);
    const exam = store.getExam(a.examId);
    const r = a.result || {};
    const cells = [
      cand?.name ?? '', exam?.title ?? '', r.score ?? 0, r.total ?? 0, r.percent ?? 0,
      r.passed ? 'Pass' : 'Fail', a.status, a.violations?.length || 0, a.submittedAt ?? '',
    ].map((c) => `"${String(c).replace(/"/g, '""')}"`);
    lines.push(cells.join(','));
  }
  downloadFile('exam-results.csv', lines.join('\n'), 'text/csv');
  toast('CSV exported', 'ok');
}

/* ═══════════════════════════════════════════════════════
   SETTINGS TAB
   ═══════════════════════════════════════════════════════ */

function renderSettings() {
  const host = $('#tab-settings');
  host.innerHTML = '';

  const me = store.me() || {};
  const envManaged = !!me.passwordManagedByEnv;

  const cur = el('input', { type: 'password', placeholder: 'Current password', autocomplete: 'current-password', disabled: envManaged ? 'disabled' : null });
  const p1 = el('input', { type: 'password', placeholder: 'New password', autocomplete: 'new-password', disabled: envManaged ? 'disabled' : null });
  const p2 = el('input', { type: 'password', placeholder: 'Confirm new password', autocomplete: 'new-password', disabled: envManaged ? 'disabled' : null });

  host.append(el('div', { class: 'card' }, [
    el('div', { class: 'card-hd' }, [el('h3', {}, 'My password')]),
    el('p', { class: 'muted', style: 'font-size:0.82rem;margin-bottom:12px;' },
      `Signed in as ${esc(me.displayName || me.username || 'admin')}.`),

    me.role === 'master' && me.usingDefaultPassword && !envManaged
      ? el('p', { style: 'font-size:0.85rem;color:#fcd34d;background:rgba(245,158,11,0.09);border:1px solid rgba(245,158,11,0.3);border-radius:11px;padding:11px 13px;margin-bottom:14px;' },
          '⚠ The master account is still using the default password (1234). Change it before issuing any access codes.')
      : null,

    envManaged
      ? el('p', { class: 'muted', style: 'font-size:0.85rem;background:rgba(0,102,255,0.08);border:1px solid var(--border-hover);border-radius:11px;padding:11px 13px;' },
          'The master password is set by the EXAM_ADMIN_PIN environment variable, so it cannot be changed here. Update that variable and restart the server.')
      : null,

    labeled('Current password', cur),
    labeled('New password', p1),
    labeled('Confirm new password', p2),
    el('button', { class: 'btn btn-primary', disabled: envManaged ? 'disabled' : null, onclick: async (e) => {
      const c = cur.value, a = p1.value.trim(), b = p2.value.trim();
      if (!a) { toast('New password cannot be empty', 'err'); return; }
      if (a.length < 4) { toast('Use at least 4 characters', 'err'); return; }
      if (a !== b) { toast('Passwords do not match', 'err'); return; }
      e.target.disabled = true;
      try {
        await store.changeMyPassword(c, a);
        cur.value = p1.value = p2.value = '';
        if (store.me()) store.me().usingDefaultPassword = (a === '1234');
        toast('Password updated', 'ok');
        renderSettings();
      } catch (err) {
        toast(err.message, 'err');
      } finally {
        e.target.disabled = false;
      }
    } }, 'Update password'),

    me.role === 'master'
      ? el('p', { class: 'muted', style: 'font-size:0.78rem;margin-top:12px;' },
          'Locked out entirely? See “Resetting a forgotten PIN” in DEPLOY-VM.md.')
      : null,
  ]));

  // Backup & reset — full-data operations, so gate the destructive ones.
  const canWriteAll = store.can('exams') && store.can('candidates');
  host.append(el('div', { class: 'card' }, [
    el('div', { class: 'card-hd' }, [el('h3', {}, 'Backup & data')]),
    el('p', { class: 'muted', style: 'font-size:0.85rem;margin-bottom:14px;' },
      'Exams and results are stored on the server, so any candidate can sit them from their own device. Export a backup before making large changes.'),
    el('div', { class: 'row wrap-row', style: 'gap:10px;' }, [
      el('button', { class: 'btn btn-ghost', onclick: () => { downloadFile('starai-exam-backup.json', store.exportAll(), 'application/json'); toast('Backup downloaded', 'ok'); } }, '⇩ Export backup'),
      canWriteAll ? el('button', { class: 'btn btn-ghost', onclick: importBackup }, '⇪ Import backup') : null,
      canWriteAll ? el('button', { class: 'btn btn-danger', onclick: async () => {
        if (!(await confirmModal({ title: 'Reset everything?', body: 'Deletes all exams and candidate codes on the server. Submitted results are kept.', okLabel: 'Reset all', danger: true }))) return;
        try {
          await store.resetAll();
          toast('All exams cleared'); renderExams(); renderResults(); renderSettings();
        } catch (err) { toast(`Reset failed: ${err.message}`, 'err'); }
      } }, '⌫ Reset all data') : null,
    ]),
  ]));
}

function importBackup() {
  const input = el('input', { type: 'file', accept: 'application/json', style: 'display:none;' });
  input.addEventListener('change', () => {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        await store.importAll(reader.result);
        toast('Backup imported', 'ok');
        renderExams(); renderResults(); renderSettings();
      } catch (e) {
        toast(e instanceof SyntaxError ? 'Invalid backup file' : `Import failed: ${e.message}`, 'err');
      }
    };
    reader.readAsText(file);
  });
  document.body.append(input);
  input.click();
  input.remove();
}

/* ── small builders ──────────────────────────────────── */

function labeled(label, control) {
  return el('label', { class: 'field' }, [el('span', {}, label), control]);
}
function input(type, value, oninput, extra = {}) {
  return el('input', { type, value, oninput, ...extra });
}
function textarea(value, oninput) {
  const t = el('textarea', { oninput });
  t.value = value;
  return t;
}
function checkbox(label, checked, onchange) {
  return el('label', { class: 'check' }, [el('input', { type: 'checkbox', checked: checked ? 'checked' : null, onchange }), label]);
}
function stat(n, l) {
  return el('div', { class: 'stat' }, [el('div', { class: 'n' }, String(n)), el('div', { class: 'l' }, l)]);
}
function downloadFile(name, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = el('a', { href: url, download: name });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* ═══════════════════════════════════════════════════════
   ADMINS TAB (master only)
   ═══════════════════════════════════════════════════════ */

const PERM_LABELS = { exams: 'Exams', candidates: 'Candidates', results: 'Results', ai: 'AI generation' };

async function renderAdmins() {
  const host = $('#tab-admins');
  if (!host) return;
  const me = store.me() || {};
  if (!me.canManageAdmins) { host.innerHTML = ''; return; }

  host.innerHTML = '';
  const wrap = el('div', {});
  host.append(wrap);
  wrap.append(el('div', { class: 'card' }, [el('div', { class: 'empty' }, 'Loading admins…')]));

  let admins;
  try {
    admins = await store.listAdmins();
  } catch (err) {
    wrap.innerHTML = '';
    wrap.append(el('div', { class: 'card' }, [el('p', { class: 'muted' }, `Could not load admins: ${esc(err.message)}`)]));
    return;
  }

  wrap.innerHTML = '';
  wrap.append(createAdminCard());
  wrap.append(adminListCard(admins, me));
}

function createAdminCard() {
  const username = el('input', { type: 'text', placeholder: 'username', autocapitalize: 'none', class: 'grow' });
  const displayName = el('input', { type: 'text', placeholder: 'Display name (optional)', class: 'grow' });
  const password = el('input', { type: 'password', placeholder: 'Password (min 4)', class: 'grow' });

  const perms = {};
  const permBoxes = Object.entries(PERM_LABELS).map(([key, label]) => {
    const cb = el('input', { type: 'checkbox', checked: 'checked' });
    perms[key] = cb;
    return el('label', { class: 'check' }, [cb, label]);
  });

  const create = async (btn) => {
    btn.disabled = true;
    try {
      await store.createAdmin({
        username: username.value.trim(),
        displayName: displayName.value.trim(),
        password: password.value,
        perms: Object.fromEntries(Object.entries(perms).map(([k, cb]) => [k, cb.checked])),
      });
      toast('Admin created', 'ok');
      renderAdmins();
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      btn.disabled = false;
    }
  };

  return el('div', { class: 'card' }, [
    el('div', { class: 'card-hd' }, [
      el('div', {}, [
        el('h3', {}, 'Add an admin'),
        el('p', { class: 'muted', style: 'font-size:0.82rem;' }, 'Each admin signs in with their own username and password. Tick the areas they may manage.'),
      ]),
    ]),
    el('div', { class: 'field-row' }, [labeled('Username', username), labeled('Display name', displayName)]),
    labeled('Password', password),
    el('div', {}, [
      el('span', { style: 'display:block;font-size:0.82rem;color:var(--muted);margin-bottom:6px;font-weight:600;' }, 'Permissions'),
      el('div', { class: 'row wrap-row', style: 'gap:14px;' }, permBoxes),
    ]),
    el('div', { class: 'row', style: 'justify-content:flex-end;margin-top:14px;' }, [
      el('button', { class: 'btn btn-primary', onclick: (e) => create(e.target) }, '＋ Create admin'),
    ]),
  ]);
}

function adminListCard(admins, me) {
  const rows = admins.map((a) => adminRow(a, me));
  return el('div', { class: 'card' }, [
    el('div', { class: 'card-hd' }, [el('h3', {}, `Admin accounts (${admins.length})`)]),
    el('div', { class: 'tbl-wrap' }, [
      el('table', {}, [
        el('thead', {}, [el('tr', {}, ['Admin', 'Role', 'Status', 'Permissions', 'Last sign-in', 'Actions'].map((h) => el('th', {}, h)))]),
        el('tbody', {}, rows),
      ]),
    ]),
  ]);
}

function adminRow(a, me) {
  const isMaster = a.role === 'master';
  const isSelf = a.id === me.id;

  // permission chips (master → all, editable only for workers)
  const permCell = isMaster
    ? el('span', { class: 'muted', style: 'font-size:0.8rem;' }, 'All (master)')
    : el('div', { class: 'row wrap-row', style: 'gap:8px;' },
        Object.entries(PERM_LABELS).map(([key, label]) => {
          const cb = el('input', {
            type: 'checkbox', checked: a.perms[key] ? 'checked' : null,
            onchange: async () => {
              const next = { ...a.perms, [key]: cb.checked };
              try { await store.updateAdmin(a.id, { perms: next }); a.perms = next; toast('Permissions updated', 'ok'); }
              catch (err) { cb.checked = a.perms[key]; toast(err.message, 'err'); }
            },
          });
          return el('label', { class: 'check', style: 'font-size:0.78rem;gap:5px;' }, [cb, label]);
        }));

  const statusPill = a.enabled
    ? el('span', { class: 'pill pill-green' }, 'Enabled')
    : el('span', { class: 'pill pill-red' }, 'Disabled');

  const actions = el('div', { class: 'row wrap-row', style: 'gap:6px;' });

  if (isMaster) {
    actions.append(el('span', { class: 'muted', style: 'font-size:0.78rem;' }, isSelf ? 'you · change password in Settings' : 'master'));
  } else {
    // enable / disable
    actions.append(el('button', {
      class: `btn btn-sm ${a.enabled ? 'btn-ghost' : 'btn-orange'}`,
      onclick: async (e) => {
        e.target.disabled = true;
        try { await store.updateAdmin(a.id, { enabled: !a.enabled }); toast(a.enabled ? 'Admin disabled' : 'Admin enabled', 'ok'); renderAdmins(); }
        catch (err) { toast(err.message, 'err'); e.target.disabled = false; }
      },
    }, a.enabled ? 'Disable' : 'Enable'));

    // reset password
    actions.append(el('button', { class: 'btn btn-ghost btn-sm', onclick: () => resetAdminPasswordModal(a) }, 'Reset password'));

    // delete
    actions.append(el('button', { class: 'btn btn-danger btn-sm', onclick: async () => {
      if (!(await confirmModal({ title: `Delete ${esc(a.username)}?`, body: 'This admin will be signed out and removed. Exams and results are untouched.', okLabel: 'Delete', danger: true }))) return;
      try { await store.deleteAdmin(a.id); toast('Admin deleted', 'ok'); renderAdmins(); }
      catch (err) { toast(err.message, 'err'); }
    } }, '🗑'));
  }

  return el('tr', {}, [
    el('td', {}, [
      el('div', { style: 'font-weight:700;' }, a.displayName || a.username),
      el('div', { class: 'muted', style: 'font-size:0.78rem;' }, `@${a.username}`),
    ]),
    el('td', {}, [isMaster ? el('span', { class: 'pill pill-blue' }, 'Master') : el('span', { class: 'pill pill-gray' }, 'Admin')]),
    el('td', {}, [statusPill]),
    el('td', { style: 'white-space:normal;' }, [permCell]),
    el('td', {}, a.lastLoginAt ? fmtDate(a.lastLoginAt) : '—'),
    el('td', {}, [actions]),
  ]);
}

function resetAdminPasswordModal(a) {
  const p1 = el('input', { type: 'password', placeholder: 'New password (min 4)', autocomplete: 'new-password' });
  const host = el('div', { class: 'modal-host', onclick: (e) => { if (e.target === host) host.remove(); } }, [
    el('div', { class: 'modal', style: 'max-width:420px;' }, [
      el('h3', { style: 'font-size:1.15rem;margin-bottom:6px;' }, `Reset password — ${esc(a.username)}`),
      el('p', { class: 'muted', style: 'font-size:0.83rem;margin-bottom:12px;' }, 'The admin is signed out and must use the new password next time.'),
      labeled('New password', p1),
      el('div', { class: 'row', style: 'justify-content:flex-end;gap:8px;margin-top:6px;' }, [
        el('button', { class: 'btn btn-ghost', onclick: () => host.remove() }, 'Cancel'),
        el('button', { class: 'btn btn-primary', onclick: async (e) => {
          const pw = p1.value.trim();
          if (pw.length < 4) { toast('Use at least 4 characters', 'err'); return; }
          e.target.disabled = true;
          try { await store.resetAdminPassword(a.id, pw); host.remove(); toast('Password reset', 'ok'); }
          catch (err) { toast(err.message, 'err'); e.target.disabled = false; }
        } }, 'Reset password'),
      ]),
    ]),
  ]);
  document.body.append(host);
}

/* ── boot ────────────────────────────────────────────── */
if (store.isSignedIn()) showApp();
