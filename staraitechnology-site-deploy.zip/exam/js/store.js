/* ===========================================================
   Star Ai Exam Suite — store.js  (admin side)
   Server-backed replacement for the old localStorage store.

   Exams, codes, the answer key and scoring now live on the server
   (/api/*), because localStorage is per-browser: a candidate opening
   the site on their own device saw an empty database and every access
   code came back "invalid".

   Shape: the whole admin DB is cached in memory so the existing
   synchronous editor code keeps working; writes mark the cache dirty
   and push to the server on a short debounce.

   Attempts are read-only here — they belong to the candidate endpoints,
   so an admin save can never clobber a live sitting.
   =========================================================== */

const API = '/api';
const TOKEN_KEY = 'zelite.exam.adminToken';

let db = { exams: [], candidates: [], attempts: [] };
let dirtyExams = false;
let dirtyCands = false;
let pushTimer = null;
let inFlight = null;
const listeners = new Set();

/* who is signed in (perms, role) — populated by login/connect */
let serverMe = null;

/* ── transport ───────────────────────────────────────────── */

function authToken() {
  return sessionStorage.getItem(TOKEN_KEY);
}

async function call(path, { method = 'GET', body, auth = true } = {}) {
  const headers = {};
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (auth && authToken()) headers.authorization = `Bearer ${authToken()}`;

  const res = await fetch(`${API}/${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }

  if (!res.ok) {
    const err = new Error(data?.error || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

/* ── sync status (for the "saving…" indicator) ───────────── */

export function onSync(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
function emit(state, detail) {
  for (const fn of listeners) fn(state, detail);
}
export function hasPendingWrites() {
  return dirtyExams || dirtyCands || !!inFlight;
}

/* ── session & identity ──────────────────────────────────── */

export function isSignedIn() {
  return !!authToken();
}

/* Current admin: { id, username, displayName, role, enabled, perms,
   canManageAdmins, passwordManagedByEnv, usingDefaultPassword }. */
export function me() { return serverMe; }

export function can(perm) {
  if (!serverMe) return false;
  if (serverMe.role === 'master') return true;
  return !!(serverMe.perms && serverMe.perms[perm]);
}

export async function login(username, password) {
  const { token, me: whoami } = await call('admin/login', {
    method: 'POST', body: { username, password }, auth: false,
  });
  sessionStorage.setItem(TOKEN_KEY, token);
  serverMe = whoami;
  return whoami;
}

export function logout() {
  sessionStorage.removeItem(TOKEN_KEY);
  serverMe = null;
}

/* change your own password */
export async function changeMyPassword(currentPassword, newPassword) {
  await call('admin/password', { method: 'POST', body: { currentPassword, newPassword } });
}

/* ── master: manage worker admins ────────────────────────── */

export async function listAdmins() {
  const { admins } = await call('admin/admins');
  return admins ?? [];
}
export async function createAdmin({ username, password, displayName, perms }) {
  const { admin } = await call('admin/admins/create', { method: 'POST', body: { username, password, displayName, perms } });
  return admin;
}
export async function updateAdmin(id, patch) {
  const { admin } = await call('admin/admins/update', { method: 'POST', body: { id, ...patch } });
  return admin;
}
export async function resetAdminPassword(id, password) {
  await call('admin/admins/password', { method: 'POST', body: { id, password } });
}
export async function deleteAdmin(id) {
  await call('admin/admins/delete', { method: 'POST', body: { id } });
}

/* ── load / save ─────────────────────────────────────────── */

/* ── AI authoring ────────────────────────────────────────── */

export async function aiDescription(title) {
  const { description } = await call('admin/generate', {
    method: 'POST', body: { mode: 'description', title },
  });
  return description;
}

export async function aiQuestions(title, count, avoid) {
  const { questions } = await call('admin/generate', {
    method: 'POST', body: { mode: 'questions', title, count, avoid },
  });
  return questions ?? [];
}

export async function connect() {
  const data = await call('admin/db');
  db = {
    exams: data.exams ?? [],
    candidates: data.candidates ?? [],
    attempts: data.attempts ?? [],
  };
  serverMe = {
    ...(data.me ?? {}),
    aiEnabled: !!data.aiEnabled,
    usingDefaultPassword: !!data.usingDefaultPassword,
  };
  return db;
}

/* Re-reads attempts so results appear without a full page reload. */
export async function refreshAttempts() {
  const data = await call('admin/db');
  db.attempts = data.attempts ?? [];
  return db.attempts;
}

/* Exams and candidates are pushed to separate, permission-gated
   endpoints, so an admin who may only issue codes never attempts an
   exam write (which the server would reject). */
function markDirty(kind) {
  if (kind === 'exams') dirtyExams = true;
  else if (kind === 'candidates') dirtyCands = true;
  emit('dirty');
  clearTimeout(pushTimer);
  pushTimer = setTimeout(flush, 600);
}

export async function flush() {
  clearTimeout(pushTimer);
  if (!dirtyExams && !dirtyCands) return;
  if (inFlight) return inFlight;           // a push is already running

  const pushExams = dirtyExams;
  const pushCands = dirtyCands;
  dirtyExams = false;
  dirtyCands = false;
  emit('saving');

  const jobs = [];
  if (pushExams) jobs.push(call('admin/exams', { method: 'PUT', body: { exams: db.exams } }));
  if (pushCands) jobs.push(call('admin/candidates', { method: 'PUT', body: { candidates: db.candidates } }));

  inFlight = Promise.all(jobs)
    .then(() => emit('saved'))
    .catch((err) => {
      if (pushExams) dirtyExams = true;    // keep the change so it retries
      if (pushCands) dirtyCands = true;
      emit('error', err);
      throw err;
    })
    .finally(() => { inFlight = null; });

  return inFlight;
}

/* Don't let a browser close swallow the last edit. */
window.addEventListener('beforeunload', (e) => {
  if (hasPendingWrites()) {
    flush();
    e.preventDefault();
    e.returnValue = '';
  }
});

/* ── ids & codes ─────────────────────────────────────────── */

export function uid(prefix = 'id') {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-4)}`;
}

export function accessCode(len = 6) {
  // No 0/O/1/I — these get mistyped when read off a printout.
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  const buf = new Uint32Array(len);
  crypto.getRandomValues(buf);
  for (let i = 0; i < len; i++) out += alphabet[buf[i] % alphabet.length];
  return out;
}

/* A duplicate code would let two people share one login. */
export function uniqueAccessCode(len = 6) {
  const taken = new Set(db.candidates.map((c) => c.code));
  for (let i = 0; i < 200; i++) {
    const code = accessCode(len);
    if (!taken.has(code)) return code;
  }
  return accessCode(len + 2);
}

/* ── model ───────────────────────────────────────────────── */

export function blankExam() {
  return {
    id: uid('exam'),
    title: 'Untitled Exam',
    description: '',
    durationMin: 30,
    passPercent: 40,
    negativeMark: 0,
    shuffleQuestions: true,
    shuffleOptions: true,
    maxViolations: 3,
    showResultToCandidate: true,
    status: 'draft',
    questions: [],
    createdAt: new Date().toISOString(),
  };
}

export function blankQuestion() {
  return {
    id: uid('q'),
    text: '',
    options: ['', '', '', ''],
    correct: 0,
    marks: 1,
    section: '',
  };
}

export function examTotalMarks(exam) {
  return exam.questions.reduce((sum, q) => sum + (Number(q.marks) || 0), 0);
}

/* Returns human-readable problems; empty means safe to publish. */
export function validateExam(exam) {
  const issues = [];
  if (!exam.questions.length) issues.push('The exam has no questions.');
  if (!String(exam.title).trim()) issues.push('The exam has no title.');
  if (!(Number(exam.durationMin) > 0)) issues.push('Duration must be greater than 0 minutes.');

  exam.questions.forEach((q, i) => {
    const n = `Q${i + 1}`;
    if (!String(q.text).trim()) issues.push(`${n}: question text is empty.`);

    const filled = q.options.filter((o) => String(o).trim() !== '');
    if (filled.length < 2) issues.push(`${n}: needs at least 2 non-empty options.`);

    if (!(q.correct >= 0 && q.correct < q.options.length)) issues.push(`${n}: no valid correct answer is marked.`);
    else if (!String(q.options[q.correct]).trim()) issues.push(`${n}: the correct option is blank.`);

    if (!(Number(q.marks) > 0)) issues.push(`${n}: marks must be greater than 0.`);
  });

  return issues;
}

/* Local scoring, used only to render the admin's answer review.
   The authoritative score is computed on the server. */
export function scoreAttempt(exam, attempt) {
  let score = 0, correct = 0, wrong = 0, skipped = 0;
  for (const q of exam.questions) {
    const given = attempt.answers[q.id];
    if (given === undefined || given === null) { skipped++; continue; }
    if (given === q.correct) { correct++; score += Number(q.marks) || 0; }
    else { wrong++; score -= Number(exam.negativeMark) || 0; }
  }
  const total = examTotalMarks(exam);
  score = Math.max(0, Math.round(score * 100) / 100);
  const percent = total > 0 ? Math.round((score / total) * 1000) / 10 : 0;
  return { score, total, percent, correct, wrong, skipped, passed: percent >= (Number(exam.passPercent) || 0) };
}

/* ── exams ───────────────────────────────────────────────── */

export function listExams() { return db.exams; }
export function getExam(id) { return db.exams.find((e) => e.id === id) || null; }

export function saveExam(exam) {
  const i = db.exams.findIndex((e) => e.id === exam.id);
  if (i === -1) db.exams.push(exam);
  else db.exams[i] = exam;
  markDirty('exams');
  return exam;
}

export function deleteExam(id) {
  const hadCands = db.candidates.some((c) => c.examId === id);
  db.exams = db.exams.filter((e) => e.id !== id);
  db.candidates = db.candidates.filter((c) => c.examId !== id);
  markDirty('exams');
  if (hadCands) markDirty('candidates');   // its codes went too
}

/* ── candidates ──────────────────────────────────────────── */

export function listCandidates(examId) {
  return examId ? db.candidates.filter((c) => c.examId === examId) : db.candidates;
}

export function findCandidateByCode(code) {
  const want = String(code || '').trim().toUpperCase();
  return want ? db.candidates.find((c) => c.code === want) || null : null;
}

export function saveCandidate(candidate) {
  const i = db.candidates.findIndex((c) => c.id === candidate.id);
  if (i === -1) db.candidates.push(candidate);
  else db.candidates[i] = candidate;
  markDirty('candidates');
  return candidate;
}

export function deleteCandidate(id) {
  db.candidates = db.candidates.filter((c) => c.id !== id);
  markDirty('candidates');
}

/* ── attempts (read-only; owned by the candidate endpoints) ─ */

export function listAttempts(examId) {
  return examId ? db.attempts.filter((a) => a.examId === examId) : db.attempts;
}

export function getAttempt(id) { return db.attempts.find((a) => a.id === id) || null; }
export function findAttemptByCandidate(candidateId) {
  return db.attempts.find((a) => a.candidateId === candidateId) || null;
}

export async function deleteAttempt(id) {
  await call('admin/attempt', { method: 'DELETE', body: { id } });
  db.attempts = db.attempts.filter((a) => a.id !== id);
}

/* ── backup ──────────────────────────────────────────────── */

export function exportAll() {
  return JSON.stringify({ exams: db.exams, candidates: db.candidates, attempts: db.attempts }, null, 2);
}

export async function importAll(jsonText) {
  const parsed = JSON.parse(jsonText);
  if (!parsed || typeof parsed !== 'object') throw new Error('Not a valid backup file.');
  db.exams = parsed.exams ?? [];
  db.candidates = parsed.candidates ?? [];
  markDirty('exams');
  markDirty('candidates');
  await flush();
}

export async function resetAll() {
  db.exams = [];
  db.candidates = [];
  markDirty('exams');
  markDirty('candidates');
  await flush();
}
