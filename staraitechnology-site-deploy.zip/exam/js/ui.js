/* ===========================================================
   Star Ai Exam Suite — ui.js
   Tiny DOM helpers: escaping, toasts, confirm modal.
   =========================================================== */

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined) node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c === null || c === undefined) continue;
    node.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return node;
}

export function esc(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

/* ── toast ───────────────────────────────────────────── */

function toastHost() {
  let host = document.querySelector('.toast-host');
  if (!host) {
    host = el('div', { class: 'toast-host' });
    document.body.append(host);
  }
  return host;
}

export function toast(msg, kind = '') {
  const node = el('div', { class: `toast ${kind}` }, msg);
  toastHost().append(node);
  setTimeout(() => {
    node.style.transition = 'opacity .3s, transform .3s';
    node.style.opacity = '0';
    node.style.transform = 'translateY(8px)';
    setTimeout(() => node.remove(), 300);
  }, 3200);
}

/* ── confirm modal ───────────────────────────────────── */

export function confirmModal({ title = 'Are you sure?', body = '', okLabel = 'Confirm', danger = false } = {}) {
  return new Promise((resolve) => {
    const close = (val) => { host.remove(); resolve(val); };
    const host = el('div', { class: 'modal-host', onclick: (e) => { if (e.target === host) close(false); } }, [
      el('div', { class: 'modal' }, [
        el('h3', { style: 'font-size:1.15rem;margin-bottom:10px;' }, title),
        body ? el('p', { class: 'muted', style: 'margin-bottom:20px;' }, body) : null,
        el('div', { class: 'row', style: 'justify-content:flex-end;' }, [
          el('button', { class: 'btn btn-ghost', onclick: () => close(false) }, 'Cancel'),
          el('button', { class: `btn ${danger ? 'btn-danger' : 'btn-primary'}`, onclick: () => close(true) }, okLabel),
        ]),
      ]),
    ]);
    document.body.append(host);
  });
}

export function fmtDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}
