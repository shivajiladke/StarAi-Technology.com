Place your brand assets here:
- logo.svg / logo.png       (company logo)
- og-banner.png             (1200x630, used for LinkedIn/social link previews)
- favicon files (optional)

The site currently uses an inline SVG favicon, so it works without these.
Add og-banner.png to make shared links look great on LinkedIn.
